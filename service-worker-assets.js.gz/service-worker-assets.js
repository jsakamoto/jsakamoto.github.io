self.assetsManifest = {
  "version": "4/5xgcPd",
  "assets": [
    {
      "hash": "sha256-AHn7kYyuEo98bV8uBp1gDXi3t2x5Ht4SfV8RB6LF6j4=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-Kfky1A8y9+ZwzlY43QWt+NQrv66OFcXP+yN4JDCOmuQ=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.9c7g4riq4n.lib.module.js"
    },
    {
      "hash": "sha256-La623j6ukTkJbthQXrC6ajO4tMgp2awVG5rMqqPD49U=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-3pKTLyHO+S4KpvfUJF6OxoGvxm+DT7p4A4SXe2ocNj8=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bnjuj6nd91.bundle.scp.css"
    },
    {
      "hash": "sha256-kGbF23HTJ7fuLMePuIvmp4+k696ZMC1z26ZM12xE4Mc=",
      "url": "_framework/CUIFlavoredPortfolioSite.spxrabip6a.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-XZuznnedra1n7iTDOq+GDN60qpucL0PYmc2gcIyrF/Q=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.t8i8dg6rz2.wasm"
    },
    {
      "hash": "sha256-lRM9I8mc3VYcG5YjeZZI01WSKsHeHrKY6FSHv0PIjwM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5ksckt1now.wasm"
    },
    {
      "hash": "sha256-bvJTOLkAblXvvE6PRHa+yIbD4M/kQmadur8AymFmplM=",
      "url": "_framework/Microsoft.AspNetCore.Components.mjlmfuprfx.wasm"
    },
    {
      "hash": "sha256-0V5Tiw40e0IqqVGavBVzZGwRFT06zo3LDh38bvE2lmE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.ln8c88gm6m.wasm"
    },
    {
      "hash": "sha256-uS4dAB5LCBE48weWfB+F4dszDdQmsQufFxDHoxtPc1w=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.tj3r8jzy7i.wasm"
    },
    {
      "hash": "sha256-3MtYBaiuaVyuOpdjT3YvBl7xgsTQ+lv38+lAxvnuHqQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.wh2m62rrpm.wasm"
    },
    {
      "hash": "sha256-rODh0esS4ZRQ+hKY8BECMRStMdMprLV7zjiWKsrsZB0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.cc3zdi389d.wasm"
    },
    {
      "hash": "sha256-ctSBjMN5PkSZI4JJPQNlDqg5fqf4UvWU80mE3yDF+MQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.mqlmwdm595.wasm"
    },
    {
      "hash": "sha256-CHd+A+JoKTRKBPoVvl/AA3aoYBRXMlVuLFgZvTQ8mV8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.os8awfbnav.wasm"
    },
    {
      "hash": "sha256-W+KhR189qaF1RXggadWm99zEXjKroNmXpogMz1QAPLc=",
      "url": "_framework/Microsoft.Extensions.Logging.fvb9eky66p.wasm"
    },
    {
      "hash": "sha256-r9WfTu2hE1ffnXRZoj9RHHu8j2QswsLC0YctkoGpq80=",
      "url": "_framework/Microsoft.Extensions.Options.h0gdcfrbcp.wasm"
    },
    {
      "hash": "sha256-Iull93mo1FU7W4bYG9pGpMAK6eDLO7SsVC6SbugE9MQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.i0puz3qu8l.wasm"
    },
    {
      "hash": "sha256-5F4rr/Clvsocajw2ftvbRO0MuNWQW7yTOzEC3K/UsjQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.on5x8zdasp.wasm"
    },
    {
      "hash": "sha256-PUzrZXLyuW3uWAQzSOqiiBDzLvyeDXlvJAxv4S6SOHU=",
      "url": "_framework/Microsoft.JSInterop.nfpgrxfnsg.wasm"
    },
    {
      "hash": "sha256-zAzj1kDQ6FsnUHFI7XohAaBdB3urk9s6CaAZ6k/RVDw=",
      "url": "_framework/System.Collections.Concurrent.s8dzjzwykl.wasm"
    },
    {
      "hash": "sha256-boT687jR5K3OhDmDzNVwcTpGZq83COtIDPtiUKWbv2k=",
      "url": "_framework/System.Collections.Immutable.i43nwz8sda.wasm"
    },
    {
      "hash": "sha256-TMhlPnSC3Tx64VrkqDs3fQibxM8rqxY3ZaOIdwIHBCU=",
      "url": "_framework/System.Collections.wfpi709qv3.wasm"
    },
    {
      "hash": "sha256-p71qY3CJ2M7GFRdNnKjiibUoh6lHtjKov0bviTqYdio=",
      "url": "_framework/System.ComponentModel.t7sahpm2wy.wasm"
    },
    {
      "hash": "sha256-Gm+r+VOxdbThsNjeraBjV6Aqem0wj+mbjYin86tuHVI=",
      "url": "_framework/System.Console.6o809fut9h.wasm"
    },
    {
      "hash": "sha256-ecxPO6FMtmoZqAuKISL9s5vqxiD+31yy2JGxcYl1zGc=",
      "url": "_framework/System.IO.Compression.5lczu55tsv.wasm"
    },
    {
      "hash": "sha256-8ZfGS2A9bBkgW4If3t7ObLJH+ooxcFvQ8IlHjNRdOzA=",
      "url": "_framework/System.IO.Pipelines.lnqobcanli.wasm"
    },
    {
      "hash": "sha256-9X6hfPIlejRHk/Fj975d56jC1Px3MvvjlUnTd1x/yxw=",
      "url": "_framework/System.Linq.dasn8ik7zw.wasm"
    },
    {
      "hash": "sha256-Oc9EH+kySNwKEzcQBa/womRL5PyWetMLhpMlENHfBvY=",
      "url": "_framework/System.Memory.xq7c1nwn4c.wasm"
    },
    {
      "hash": "sha256-qblMFhFxh73Pg9NQVq5SqzrK1tg2BcjXPpHFlpbXCrk=",
      "url": "_framework/System.Net.Http.j594r98w0r.wasm"
    },
    {
      "hash": "sha256-90SNSqtXYy19pRn0tqwHukL3v2mDHy05djE3utD3twY=",
      "url": "_framework/System.Net.Primitives.veuwbu8dr8.wasm"
    },
    {
      "hash": "sha256-eeGcEsiQDVE1eQNycDqzUioXpVPQb8CoawU/nLQUTdM=",
      "url": "_framework/System.Private.CoreLib.lh4f5qx593.wasm"
    },
    {
      "hash": "sha256-eo5qEPCGfKZRU9oy4vO7CjeE/uSlA2F1pesE3KZHWDs=",
      "url": "_framework/System.Private.Uri.u3zrcqjdrr.wasm"
    },
    {
      "hash": "sha256-2QJgEEApsiNsQeij+byUI7EN0UItZqvMwRA5w5PQP2c=",
      "url": "_framework/System.Reflection.1em29z14nl.wasm"
    },
    {
      "hash": "sha256-07IVl9mLsCAmiBjt7pPegbSgBls3nbPzwMd5pbgU80Q=",
      "url": "_framework/System.Reflection.Extensions.nr7aluo2n2.wasm"
    },
    {
      "hash": "sha256-cAJyzNim8eU8BEiRXT/ozut00P/UkxFZx6iT+gxP9SY=",
      "url": "_framework/System.Runtime.0wz3ieesr8.wasm"
    },
    {
      "hash": "sha256-paK97RMN2Gv29iuWOlLed+yrl+egZBxePD/DM0OTmFk=",
      "url": "_framework/System.Runtime.Extensions.r475uvbd5g.wasm"
    },
    {
      "hash": "sha256-6YVSlT8d6HoDr3rh4V1esD3qNQENZdvORmyKG3JVmqs=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.tbkgfzizch.wasm"
    },
    {
      "hash": "sha256-cf9w3iYmSHHD6Ugjo1UjGBjso8Q2dI0SnpAsnCM8gDs=",
      "url": "_framework/System.Text.Encodings.Web.jncmf69xd5.wasm"
    },
    {
      "hash": "sha256-fvnVfIe6Nx6D3TD2pYZ9/zJs+uqEcvgt7P28GhisD6c=",
      "url": "_framework/System.Text.Json.i0vqncotv5.wasm"
    },
    {
      "hash": "sha256-QCtPJVG5gXWb6hZPECG+2eJ2GYxoYXJLC5Cyu/lSjjY=",
      "url": "_framework/System.Text.RegularExpressions.wsf3a2dgxg.wasm"
    },
    {
      "hash": "sha256-pPI04tZ46rKzX8o+3T1QmBzzjiRpiOyGgXdYdj85cf4=",
      "url": "_framework/System.Threading.03f8nqb5yt.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-KJbTcAjOtkIifcu10IzP7LWXX2Y3+poMhMzAxQhR184=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.45ve1wi353.wasm"
    },
    {
      "hash": "sha256-f4LpyqjBWc03Q3fjea9z4gVidvDE55VMMY9WbsAGHOU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.jry656higl.wasm"
    },
    {
      "hash": "sha256-yxmijHoIMG2sOdxMexImmbEOTYDED3ERqP6exA/qsYM=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.hhcg7r9wws.wasm"
    },
    {
      "hash": "sha256-h9ZOA20tz38ZUJxe+NHALums70hYR5wPYf6oqrrHN+Q=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.vaggo630fo.wasm"
    },
    {
      "hash": "sha256-8XAwCye4L4ZSW0/0LRYvqVi/EthObz3TIgXjV+6jeM0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-/8vUfdjbWHrGXeFD9qAYuDFJ1e/ehuStp2OPTZiXByY=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-yUuLhu9SOdRQkPKWzWu89E38Mvoc393pk2HV1upd1LI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-AnJkeGwZT16rFcyuj+V1DGr0GlOJr6b91NYusL60D5I=",
      "url": "_framework/dotnet.native.ahdrx48lgf.wasm"
    },
    {
      "hash": "sha256-lZLmuV5LCQ/NZnajiw5wHo2XjLq6RE3HEH5Y6oze6PA=",
      "url": "_framework/dotnet.native.rkoo7lkv2j.js"
    },
    {
      "hash": "sha256-iTP1NrsUG+70/mXZ+coyMcrGzeqLKbOjUduaFU/0I+0=",
      "url": "_framework/dotnet.runtime.vyxa20sgey.js"
    },
    {
      "hash": "sha256-Oze1wV/bXaeBJx9d/5Kb9+fsWTzdQrNHPKwO3uAwDFk=",
      "url": "_framework/netstandard.dqljovekox.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-tRR7v6ZqfNVt4+aFOcEJrxXgZY/QUg9lcVUseqpn0Ag=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-XstODeHpSfApNv74N2EjSbPos8GR38PcxhBEt9rigMA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-RBUikAEI4NQnEO55CIYdZvR1FONxzbgclc9+WG6Pj2M=",
      "url": "site.min.css"
    }
  ]
};
