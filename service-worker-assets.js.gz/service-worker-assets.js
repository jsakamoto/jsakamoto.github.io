self.assetsManifest = {
  "version": "5uDnC6fv",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-AHn7kYyuEo98bV8uBp1gDXi3t2x5Ht4SfV8RB6LF6j4=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-j8XkbtojxRSVQ5M44HzZBCH5G9usVpjHYw1hz3nWnr0=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bnjuj6nd91.bundle.scp.css"
    },
    {
      "hash": "sha256-a2ILykDJhfDdOhyIdKnPJN6awMQoNEPSD5pgAhjFD+o=",
      "url": "_framework/CUIFlavoredPortfolioSite.50t3sj24ba.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-Fg5R9MwxIv3RrRaxyuN+TEBG8nhH/YIrvLoia7c5G8o=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.y2w6iesg2f.wasm"
    },
    {
      "hash": "sha256-81RP1LGrUeC4i4ehkML5s58iaOT1ebklUnPQUw54rIM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.doii42bkx1.wasm"
    },
    {
      "hash": "sha256-LCOtWR5Eo57GWQrm+h2iOt6DBW9eRON7RTD7GIyYPvs=",
      "url": "_framework/Microsoft.AspNetCore.Components.obb2bn1uw2.wasm"
    },
    {
      "hash": "sha256-qJcr6Fc/50eJJvdEIRfzVuRP97MNbOEuEkoYtejBW/E=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.ooq5283nf9.wasm"
    },
    {
      "hash": "sha256-RLFYrxEIqE2KAwSoDvqEMs2VE2G9puXzNx1LFr13ivI=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.0b388xm8kh.wasm"
    },
    {
      "hash": "sha256-EA7fJKb0sPjWoURBvj5OxdCgJlZHQ14EAx4z+x25btk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.82ym46gts0.wasm"
    },
    {
      "hash": "sha256-9uzRXRTGHtoNN5a1JYArLZGDblEM1l5dOWd3LB1WjgQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.uabncmb0ew.wasm"
    },
    {
      "hash": "sha256-q6Gt/KII0v+SQ57aNKcSIPUBUSB62ZZ9qashqCSzj5g=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.548xns1hi0.wasm"
    },
    {
      "hash": "sha256-fjae9ms6uE1Me1fiXTjHeyS7sjz2z9F1NmEZ7EDY+xM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.6millsohvc.wasm"
    },
    {
      "hash": "sha256-k++WrWWwGfV97/wy0sYpOhR9C1Qn5eNW95uvfBoYRpQ=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.joqu1vpo7a.wasm"
    },
    {
      "hash": "sha256-UhT//7i0SIyM+ydPz2LqK+q/hpad/FTPVFvBV3N9BEM=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.ekdkqkw9pe.wasm"
    },
    {
      "hash": "sha256-6buSBd4GbMBnyKArIKrIfIkOSKGgOA2dW3sj3znrEWI=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.huej6dt4vh.wasm"
    },
    {
      "hash": "sha256-OB8yXW/nH14Z18tw0YtM9ISyWGixUwVVs1kN/j1e3Ck=",
      "url": "_framework/Microsoft.Extensions.Logging.8gvwkdhrvs.wasm"
    },
    {
      "hash": "sha256-G/2Ctk12WGAkSN+YghLIzrm2GDN1nV7Ou4dg2xuWJ+I=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.b8zzwoqpyu.wasm"
    },
    {
      "hash": "sha256-g3w31+UBzK2umUT6/B7/4pIsS5dj8xXr/hbgv0yv17g=",
      "url": "_framework/Microsoft.Extensions.Options.lmdq85cb2o.wasm"
    },
    {
      "hash": "sha256-KTMoCbwOIebzBMBYzZ3j7rmNgr766Zwws06jeFbKCqE=",
      "url": "_framework/Microsoft.Extensions.Primitives.vm2ecztgxj.wasm"
    },
    {
      "hash": "sha256-SQy7KL8yE/Ai6o/S3L8PgiBrcBYsoedhzVIJtPIfW9A=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lhplwqly2s.wasm"
    },
    {
      "hash": "sha256-qBk40IkuTXeHQGhW2X2mMQDefn9Sjg1jUDUX3SOtaUo=",
      "url": "_framework/Microsoft.JSInterop.wyrjux5u3w.wasm"
    },
    {
      "hash": "sha256-XNXn0c4Be4dQJTBAdbuwKLbJAg4SRZji5kzQwJIz6+Q=",
      "url": "_framework/System.Collections.0j3uwmbura.wasm"
    },
    {
      "hash": "sha256-Gu9jjxsfIFUTUn2o56nFHp2YmjWAUWOX0JIjJnEnyEE=",
      "url": "_framework/System.Collections.Concurrent.22tomotpq3.wasm"
    },
    {
      "hash": "sha256-1M5JJH2fAHhR/LfqSOQxj2OHypZY3LW8nXqFilR4bz8=",
      "url": "_framework/System.Collections.Immutable.4cysud0szm.wasm"
    },
    {
      "hash": "sha256-jgOiL/Nj/WRJKK8ys6+t62ss1HGovDlBoyGRUq3c/zY=",
      "url": "_framework/System.ComponentModel.663infdl5t.wasm"
    },
    {
      "hash": "sha256-Xl7FS67c8C3Pb6/chaIHzxh32UYu8qcES4XJwI6kGf8=",
      "url": "_framework/System.Console.202ewwcpzn.wasm"
    },
    {
      "hash": "sha256-/T8k7nVVPogZmRJlyYvMk+FCpjNn1qWYjdqtkGO+CTk=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.dg75zq2vjw.wasm"
    },
    {
      "hash": "sha256-29Z2KifEvKn/JIQR0wpQd/woj09/2m/hOhaWfAEmDO4=",
      "url": "_framework/System.IO.Compression.1dxhqb4r04.wasm"
    },
    {
      "hash": "sha256-1z/9vAnY3n7LI0+1FVp9u/kRhp6UvIUyZbgQo2S8QJQ=",
      "url": "_framework/System.IO.Pipelines.9o0bktsgw7.wasm"
    },
    {
      "hash": "sha256-Tn1SLa1/hqOlnzINxG01Z86oShNjKucFaaUtiZzB/RA=",
      "url": "_framework/System.Linq.ys2yw8om1m.wasm"
    },
    {
      "hash": "sha256-3bejX6853tOSEnHdJkACcMO00zYDevxYxWXONOrry4A=",
      "url": "_framework/System.Memory.7r9nfi4m29.wasm"
    },
    {
      "hash": "sha256-F7wcn94RTKBYjsaSnifp9DOSxCnji9Z+F1L3BVm2y6E=",
      "url": "_framework/System.Net.Http.vu0nc7d2mi.wasm"
    },
    {
      "hash": "sha256-Ex5n8AWA+Z6jFbkPi77abOG0YFHL/ba3SAbrikj0R2Y=",
      "url": "_framework/System.Net.Primitives.dg2qzsmww2.wasm"
    },
    {
      "hash": "sha256-abZog2WSmedHEY+VOYxx5GH08TK2k8tNP1CnF5Qm3Uo=",
      "url": "_framework/System.Private.CoreLib.lhvkyyvjz5.wasm"
    },
    {
      "hash": "sha256-jCr5EeIu8+uGetpmvltxRhBvuzWMIMh3pDBS7XhYTX0=",
      "url": "_framework/System.Private.Uri.4gzowfd25b.wasm"
    },
    {
      "hash": "sha256-iT/vmMoL09Z5glxnx74+Xw7d3kAFc4qfeVUP3BQLAyM=",
      "url": "_framework/System.Reflection.Extensions.982djoym21.wasm"
    },
    {
      "hash": "sha256-YEihvvPCyt7ZBclpTEcURGG4AdqfXOPSrG/wgaGOREw=",
      "url": "_framework/System.Reflection.cdscl6ldea.wasm"
    },
    {
      "hash": "sha256-v5wACyC/69jktsIdvqioo6Bsm31ETiu8Wea2mqoc2Ec=",
      "url": "_framework/System.Runtime.10onqk2ppp.wasm"
    },
    {
      "hash": "sha256-0j6sMnLzs1FeQ6Q9WGx9imjWgTx6w+BVABZ0J4AYPp0=",
      "url": "_framework/System.Runtime.Extensions.qqpel0hekv.wasm"
    },
    {
      "hash": "sha256-PBWjRSA8I9kdCuOL4WGI25r/4BoDjm/iWVwrwvInGsI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ke3048uapr.wasm"
    },
    {
      "hash": "sha256-ZE7wqlIHcYwVYrIoTPDm7Zi39UzYWvgb+z6/2WfypIo=",
      "url": "_framework/System.Security.Cryptography.c25j2nnxy2.wasm"
    },
    {
      "hash": "sha256-lynNGWNoAFvlKSyhDWskDqFswwR8Ga0Cx8oRckyms98=",
      "url": "_framework/System.Text.Encodings.Web.dfc2b0g5f0.wasm"
    },
    {
      "hash": "sha256-SvvkZyOKNa8c/wiPMPNozbWSOeXFxen9YHGNEd5uPek=",
      "url": "_framework/System.Text.Json.q42ulkxm21.wasm"
    },
    {
      "hash": "sha256-4P/0fynrV5MNHyGJVI1srQXicCqw2/2Sx7nzWUb/oXA=",
      "url": "_framework/System.Text.RegularExpressions.k79xbiucpz.wasm"
    },
    {
      "hash": "sha256-vbMJVx2XHAfRUCoAMw8/FDm6GwkyX+uG89WDSPcpls4=",
      "url": "_framework/System.Threading.7zt6fsxsj5.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-v4DWIiE94uI7uw6X3QGPPFxjzvZU1tE/L1vAA5nj09A=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.zb18o0z2ij.wasm"
    },
    {
      "hash": "sha256-ZKVIic82m+pTSlJmZN1C6Vct1s78oj+PlIPpVs8nwJY=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.4k1ydz5me3.wasm"
    },
    {
      "hash": "sha256-nX3bxJFDW2YeZsn83wYeKms+LDBH87E/NO27qCxCNx0=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.dw92v4tslz.wasm"
    },
    {
      "hash": "sha256-YcT8m49nLl4G2OZzSaoVXWqvS9ApmNGGzfxUi6tcPVY=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.l7du25fzii.wasm"
    },
    {
      "hash": "sha256-4rvih6OlUJUQSz1GJ6uN5xpXWrFrItRSvRewvrKfNos=",
      "url": "_framework/blazor.webassembly.u5pmnvwhn0.js"
    },
    {
      "hash": "sha256-1grN5rEY/7WmTiIFIYUzN9AcVK2/IsgI/D7Lw5Wc4Ik=",
      "url": "_framework/dotnet.6dl8n0qvm6.js"
    },
    {
      "hash": "sha256-KwZI+IFbt/THAEYkwLDLl0lG35qvjyYQuklQrq7lTIY=",
      "url": "_framework/dotnet.native.dayx6uxni7.wasm"
    },
    {
      "hash": "sha256-UTCDWKz9Vpr8JNsjQBav91pwc7vUbhmPDl5cxFCC/tE=",
      "url": "_framework/dotnet.native.zvrqk3gpsq.js"
    },
    {
      "hash": "sha256-eNWHtM/DhhNi6xe04GlIxYNrilkrhwDV2K09+ckzb2s=",
      "url": "_framework/dotnet.runtime.kl7gvzuey0.js"
    },
    {
      "hash": "sha256-rYLgKYh+lkkwmPyNPchTGuERA+mtckc5sW9Gwb/MLuU=",
      "url": "_framework/netstandard.xvfttciqj0.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-caLBfhRoZNYEVnea2GdeyMEPEK4l5Y8vUceTwYiHAw0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-gYGp1e+rn/jn0tovVD73BTWuvxqOZaqpZ3Dmx6kuI50=",
      "url": "site.css"
    },
    {
      "hash": "sha256-flnsJUUWBgPqNGDuj/cXuR6ssRYtIryLr9EOI5ol1m8=",
      "url": "site.min.css"
    }
  ]
};
