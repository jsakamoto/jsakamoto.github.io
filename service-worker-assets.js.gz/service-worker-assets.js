self.assetsManifest = {
  "version": "4l3IV3LL",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-AHn7kYyuEo98bV8uBp1gDXi3t2x5Ht4SfV8RB6LF6j4=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-Kfky1A8y9+ZwzlY43QWt+NQrv66OFcXP+yN4JDCOmuQ=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.9c7g4riq4n.lib.module.js"
    },
    {
      "hash": "sha256-IA/Nt4K44CJSHdd49ECdOkwXOCPXawJB84eO2A5qbyk=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-j8XkbtojxRSVQ5M44HzZBCH5G9usVpjHYw1hz3nWnr0=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bnjuj6nd91.bundle.scp.css"
    },
    {
      "hash": "sha256-qDiV2O+7TWKBLRIs4DoMIn+ilxRLEKoHdxQtm1Z1FCU=",
      "url": "_framework/CUIFlavoredPortfolioSite.wadkj99we2.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-cBKwlhAa4WpaK/Y4AT1M4bMgEzQjG5BSKYj63Ige8iw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.4b2nvmlbai.wasm"
    },
    {
      "hash": "sha256-wQEdmkR0tuVmvj2HBc/0YiMb8U5plAjFjLnF4nPxvkM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.lflxzd4mw1.wasm"
    },
    {
      "hash": "sha256-CveH7k0LnAKIw1YRYgY+Iu6Tc3HK/GtMdJmncyXCKUw=",
      "url": "_framework/Microsoft.AspNetCore.Components.i577l97qxb.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-K3SPrB0AVliQFFCSYjGBZtF281xLoD+RPwZ0YN68h2Y=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.htvjkgdj5o.wasm"
    },
    {
      "hash": "sha256-KsMNGU2EADfW2aI4MH2BmQu2raDQeeWxTPKvZEpt/5o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.aju1wjeztc.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-KC6WSomDJltIxOJgYyOBoCvXBl2I5rGy3o1GpgiMNAw=",
      "url": "_framework/Microsoft.Extensions.Options.k1rlu91s0i.wasm"
    },
    {
      "hash": "sha256-r2AiYSB48Zf1KO7KxUDSpB/ndRAGSehEO9mgkbnEfCs=",
      "url": "_framework/Microsoft.Extensions.Primitives.pekkj2grdp.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-nq24EAAkRjSradov2RxvGsp0CcRKAd/+7WOmBDB2AqM=",
      "url": "_framework/Microsoft.JSInterop.qqq8d34fmv.wasm"
    },
    {
      "hash": "sha256-zeMYoU14BjRwiK9WRYYyI3fSAkYFmSd1TAJd2bPd8GM=",
      "url": "_framework/System.Collections.Concurrent.xftvh71ojz.wasm"
    },
    {
      "hash": "sha256-Et3x0kFXAZ+nr7m4EAGM5kPWiBrx9ijXp4kyK3x8+vc=",
      "url": "_framework/System.Collections.Immutable.qd8y8vah2x.wasm"
    },
    {
      "hash": "sha256-u+sJbWq5SFR0Cqq6AMpK/XRYzCqlUiKZwlehxLLJDvg=",
      "url": "_framework/System.Collections.zuy1xltejb.wasm"
    },
    {
      "hash": "sha256-/vBQJPKxuZj5hnuVviYGodmh1YjfAeyMqKIaaCNjsuQ=",
      "url": "_framework/System.ComponentModel.i0fo9h67cq.wasm"
    },
    {
      "hash": "sha256-9bkFiYFQW1hy3oULsraBW6K80F0AaAMhPF0JjzHGL7Y=",
      "url": "_framework/System.Console.9r6j5vlb1t.wasm"
    },
    {
      "hash": "sha256-6h3Tvz+DYLZ3BrZ5pkHbijDTMoTlTL4D97CayCGAUwU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2q4o0gnxbr.wasm"
    },
    {
      "hash": "sha256-oYAFZkZjU/I64ffor16jFurFPKhxy0S1sPGaw4eF6Co=",
      "url": "_framework/System.IO.Compression.9il3pq1qoh.wasm"
    },
    {
      "hash": "sha256-vB/mHpU8YWqbonbePTX22jmIRwgl+Gn2euzReK4v7es=",
      "url": "_framework/System.IO.Pipelines.8brogkqzjr.wasm"
    },
    {
      "hash": "sha256-XkRtE3FvgjG0jBVR8rDUMAei1skQkV3eBGDw/5+j5B0=",
      "url": "_framework/System.Linq.yc9lxeu4su.wasm"
    },
    {
      "hash": "sha256-0n3Lg2vXjLb3/QsQe1fYGyvlQZJUpl76I/E57wfW6ko=",
      "url": "_framework/System.Memory.mm8u3u6ygp.wasm"
    },
    {
      "hash": "sha256-SN3xREGLMZ4urYFOX4YGJNvHlvQnd7sswd5KevY3WT4=",
      "url": "_framework/System.Net.Http.o8dhoaknvo.wasm"
    },
    {
      "hash": "sha256-bZIyo1/j633N5pQMd0MwhjszHTrpQognOO74FxR9NLI=",
      "url": "_framework/System.Net.Primitives.baq20ve775.wasm"
    },
    {
      "hash": "sha256-sFJDu6GHQdEQ6OYiBeCZ/ahCIVEUJY7h6ilT1ffI16Y=",
      "url": "_framework/System.Private.CoreLib.0gzt6hta8d.wasm"
    },
    {
      "hash": "sha256-jMl5e2QevBOlKSchbow4zEhb7/s82JMt0hMMnMuPa2A=",
      "url": "_framework/System.Private.Uri.0lcregrski.wasm"
    },
    {
      "hash": "sha256-tC8fIQAVrqP0pAGxItJTwjZvRAj9SSkAr5XYTwwzSPo=",
      "url": "_framework/System.Reflection.Extensions.wv9p6zaw2s.wasm"
    },
    {
      "hash": "sha256-nz4+bhNOKgn2UIRr1RZQAm50yEaN1YJaiwfiAoxkfqc=",
      "url": "_framework/System.Reflection.l7teu2lrg9.wasm"
    },
    {
      "hash": "sha256-8bgzkT2DWEXS3m+BGhTBXIRTqU4nS9WcAA9ySGPqDeM=",
      "url": "_framework/System.Runtime.Extensions.r5ovnxycy7.wasm"
    },
    {
      "hash": "sha256-iTel8M+hoSI92c0jJFjN3ENcbqXnumik9GyNDAB4CIA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lpvs49i9za.wasm"
    },
    {
      "hash": "sha256-2bhSBiBDUNJvO68pdE6AwSa2/DE+CSInAFBzukNvNbA=",
      "url": "_framework/System.Runtime.t3tilcvaa8.wasm"
    },
    {
      "hash": "sha256-OMv0m78kVb0fejHBkAFQR8ppLcZiL/cZYoK1uiRS3rY=",
      "url": "_framework/System.Security.Cryptography.8w3aldlzuj.wasm"
    },
    {
      "hash": "sha256-nVUwAddz0b5GJqYFERy2T6IvW7DU7HWb41ynhmBW4GU=",
      "url": "_framework/System.Text.Encodings.Web.plxi32ja01.wasm"
    },
    {
      "hash": "sha256-VmJKOjkx1ZTY3tSo8V/4eNRKlZhCFSkACOXxxwNACZw=",
      "url": "_framework/System.Text.Json.agy9rrks3b.wasm"
    },
    {
      "hash": "sha256-cz9JoDrUozFpLNAsz0W10aUtqexUajHbDGzE2MaWYqI=",
      "url": "_framework/System.Text.RegularExpressions.nf0luzc1y8.wasm"
    },
    {
      "hash": "sha256-fcZeJpcx95Puk/XzRsdrgEiNvFAMILZMz6hfkexPKp8=",
      "url": "_framework/System.Threading.7jdwdkbyqt.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-KykJHUfS/oFlPFS3sHOtPpZL6VB62PlvTIBTTDJ+YwQ=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.b8cpj7rgnd.wasm"
    },
    {
      "hash": "sha256-IJMvdDVsdlziHo/bS69j2ywNOdnTsJUaXGR+Xg6p6mk=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.4nyqvrf2xd.wasm"
    },
    {
      "hash": "sha256-Ox2GAUNj5pWXKAy/SD4EXnQPNYeuMYtHttoY/A+gz34=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.lotaah4rsl.wasm"
    },
    {
      "hash": "sha256-h9ZOA20tz38ZUJxe+NHALums70hYR5wPYf6oqrrHN+Q=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.vaggo630fo.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-5OIiWsMxWXXL2H91OXPoB/CiTCD5R0Pzu0mutvz+lZI=",
      "url": "_framework/dotnet.c4gqd3ruvv.js"
    },
    {
      "hash": "sha256-G6zXon2Irlpxmz0Puwwr/mzlD9eerrblRmYBEXaJDsk=",
      "url": "_framework/dotnet.native.bcyl3iyyn8.wasm"
    },
    {
      "hash": "sha256-dt4HAth94c7/enGMI+vz35X5gRNAf7/vxViT0AjmqxI=",
      "url": "_framework/dotnet.native.eb3b8hxxf2.js"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-9Md3BeXOOs6wO/G+OaaYhlQmZyKi6QqapY+7A9qXrrg=",
      "url": "_framework/netstandard.wvdfg931oo.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-OFMV/3FkhmnL0llhWdA0/gts3untfB9JDJ1+iF1lfAk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-gYGp1e+rn/jn0tovVD73BTWuvxqOZaqpZ3Dmx6kuI50=",
      "url": "site.css"
    },
    {
      "hash": "sha256-flnsJUUWBgPqNGDuj/cXuR6ssRYtIryLr9EOI5ol1m8=",
      "url": "site.min.css"
    }
  ]
};
