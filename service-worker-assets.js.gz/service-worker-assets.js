self.assetsManifest = {
  "version": "WuALaUv8",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-AHn7kYyuEo98bV8uBp1gDXi3t2x5Ht4SfV8RB6LF6j4=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-Kfky1A8y9+ZwzlY43QWt+NQrv66OFcXP+yN4JDCOmuQ=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.9c7g4riq4n.lib.module.js"
    },
    {
      "hash": "sha256-IA/Nt4K44CJSHdd49ECdOkwXOCPXawJB84eO2A5qbyk=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-j8XkbtojxRSVQ5M44HzZBCH5G9usVpjHYw1hz3nWnr0=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bnjuj6nd91.bundle.scp.css"
    },
    {
      "hash": "sha256-KKrRgSDA8uT0ntMwYHXyeeaPt0IQuteBFHB3gscrpPE=",
      "url": "_framework/CUIFlavoredPortfolioSite.oc9uvjmzqf.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-bnKw038bp5J0NpYmbKN1soOxPwzrCd0zfJj+cn3y7eU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.u8jsult4mi.wasm"
    },
    {
      "hash": "sha256-qzI3jNEGuOw40RIbRsxa3Ysg4swvQc4dWzeCTiQWU5E=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rwxscbc5i7.wasm"
    },
    {
      "hash": "sha256-5QtTYyfblVwGP18CtenVCXvLSSNEHmAHDxGIyyOm4zE=",
      "url": "_framework/Microsoft.AspNetCore.Components.xd3z82s882.wasm"
    },
    {
      "hash": "sha256-DF5ZQPnsimHgu/OhXI14ihBGcEBOY9jXNikZbJl7ouk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gdtptxu0m1.wasm"
    },
    {
      "hash": "sha256-WQurBbuDtkPNdWdC7Lbk07OTfLLaEGN9l68/4BxEU7c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.3ped9ou2lc.wasm"
    },
    {
      "hash": "sha256-W7mtMnscYp8Lm6bOFiNQIzi2jmhPwTSt+p55NOguXJk=",
      "url": "_framework/Microsoft.Extensions.Configuration.rg826fsozh.wasm"
    },
    {
      "hash": "sha256-kYJiJeFhXmDs7Icjzjba3BaqZ8Vq58kpGAM112riBzU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.7u3sfbw88i.wasm"
    },
    {
      "hash": "sha256-rEG3da6BrNUeO3KbBWBg2CeOLGPbwAhaeQkynbC3XMQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.scyrntte5w.wasm"
    },
    {
      "hash": "sha256-dSMwazKXl9h3ma2I2eBPp+4Nv+HF4riCLGNSlu/Ss1o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.p3v4dkb093.wasm"
    },
    {
      "hash": "sha256-Qa4/Z0kdUZSeM/AH6VqMRzUW+WiiYzKP4SfIVpkTH3M=",
      "url": "_framework/Microsoft.Extensions.Logging.vgeqi1hit2.wasm"
    },
    {
      "hash": "sha256-t6XemYsg4Od+3RNHWbNTXTAJmyCfC2nQGJXurYf8N4g=",
      "url": "_framework/Microsoft.Extensions.Options.ngqrj9js31.wasm"
    },
    {
      "hash": "sha256-yy7DHdony5wli2pGMlsXB77MoIKf+tm5mkCqQNQAcKo=",
      "url": "_framework/Microsoft.Extensions.Primitives.7trog7wccl.wasm"
    },
    {
      "hash": "sha256-4I+0kHd4SomBH7+AYwAomyTpYchOHG0eb6kHl9ZrDTk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.0o8pok1eno.wasm"
    },
    {
      "hash": "sha256-C0u7DkrBPQRzhPpmU576lTuFT43A0jb2QqHcqWpre9Q=",
      "url": "_framework/Microsoft.JSInterop.nxl04ix3he.wasm"
    },
    {
      "hash": "sha256-iLzGkKMCeAzHqwt+lGCUhe7TKkTPuASokte1GFmkAK0=",
      "url": "_framework/System.Collections.Concurrent.0mi99x3axg.wasm"
    },
    {
      "hash": "sha256-fZmX5273gNTkRvE7nI+ascenV4SwijwmaN6R+v3HYG4=",
      "url": "_framework/System.Collections.Immutable.34rt0eoror.wasm"
    },
    {
      "hash": "sha256-Dmbd3NLBDsWsJgqykXFS8ZA6a3LzgtYUe3cKr1EaqJw=",
      "url": "_framework/System.Collections.epqftm1wf0.wasm"
    },
    {
      "hash": "sha256-hh9IFXL/RbhfSsmIpjQd2JKV0syxfT/lZ8Wx1o36oAE=",
      "url": "_framework/System.ComponentModel.u61y5gga6s.wasm"
    },
    {
      "hash": "sha256-OGSyeChibF2yFPVMK5+6CHC1eFFJ2j0/kamvLFoH7hE=",
      "url": "_framework/System.Console.8w8vt4xul5.wasm"
    },
    {
      "hash": "sha256-s8owNIzIl0l/kj2ZzfwMLgR2aK9BBOuGN8fiR8kyDQM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.nrl6bnnodw.wasm"
    },
    {
      "hash": "sha256-z/M2yDAdWQ9L5K785s5fLu2dFjwcuxMzRDeoPGj+NZY=",
      "url": "_framework/System.IO.Compression.r1tjerssqp.wasm"
    },
    {
      "hash": "sha256-YETgkYsSCpN1j8iN/kykAr/xvo1Wj21YdTdxzCtB1LQ=",
      "url": "_framework/System.IO.Pipelines.4f8vg2rcxi.wasm"
    },
    {
      "hash": "sha256-8IimAmwlDcZdyBmrJypZQJZ+dQXUh7RZ42cRTkW9vS0=",
      "url": "_framework/System.Linq.0wzpvikvnj.wasm"
    },
    {
      "hash": "sha256-e3ktstczwLJOZWC7ORYXetior2CYZnE4CJ0nWv4JnjA=",
      "url": "_framework/System.Memory.nh865dtzbb.wasm"
    },
    {
      "hash": "sha256-PghJmX89o6JPu1AJvEgi3/wvbTQDHEy0LCICrpXHiW4=",
      "url": "_framework/System.Net.Http.666onnery4.wasm"
    },
    {
      "hash": "sha256-Pbi0bOhF1Zd4r/RnDBDw88zKh+dEVhP2icASOjjeVTU=",
      "url": "_framework/System.Net.Primitives.dswx0h3u76.wasm"
    },
    {
      "hash": "sha256-h2siFQWIzzldoogXkKn5N9Pqr/hp53xWsODqfEiepZk=",
      "url": "_framework/System.Private.CoreLib.rflw7secsl.wasm"
    },
    {
      "hash": "sha256-452mtamaOTuFKZ5UB9j9PkdsCt/HAHtA4Ak8MH8OMKg=",
      "url": "_framework/System.Private.Uri.9hfbvo2dwo.wasm"
    },
    {
      "hash": "sha256-vaGPZ6HX2A1OTlQsHrSNILwDn6R1ZconLQw2jSSS7h0=",
      "url": "_framework/System.Reflection.Extensions.do9f7blcta.wasm"
    },
    {
      "hash": "sha256-BrzWxUgrb3aOdb0dUM9bRtXkV7raZmGiloFDIYpc6BE=",
      "url": "_framework/System.Reflection.qwi5h9mu79.wasm"
    },
    {
      "hash": "sha256-FoUKMZRqiErlrtDEiNmxlhxbQ4ATGcU/nsqKRlz4y5Y=",
      "url": "_framework/System.Runtime.Extensions.i29cam2t3l.wasm"
    },
    {
      "hash": "sha256-06lcyxHxg8ToEYAV9xVWWXf+2+2A36BLPbV1tu/iYuo=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lanx20edgb.wasm"
    },
    {
      "hash": "sha256-SEmwAo20PExIUVrodN1MGZmV5rALsqDzZPkTO0HRoV0=",
      "url": "_framework/System.Runtime.oolu8a5nwk.wasm"
    },
    {
      "hash": "sha256-2moma+Q/JRBY6Q172/lkRsN7/ZJ4sSFm1DFbCKsVvJs=",
      "url": "_framework/System.Security.Cryptography.yyjjz7spvh.wasm"
    },
    {
      "hash": "sha256-Hk+y9misZEVFBZTgloOQUZyvYWyKHy7O0KLRLZIm2zQ=",
      "url": "_framework/System.Text.Encodings.Web.6abwek7d1j.wasm"
    },
    {
      "hash": "sha256-tsSehj5Wg1zLul7SQvr9DU7WErHSOxgG5U5GbmLolzc=",
      "url": "_framework/System.Text.Json.2i4i8ji8sc.wasm"
    },
    {
      "hash": "sha256-FNKWDDHCUhTlFJdV1P4/wgJFUzwWSS/dEZCy5cAZR6E=",
      "url": "_framework/System.Text.RegularExpressions.gnuv1c3w8z.wasm"
    },
    {
      "hash": "sha256-IvgT1ij9xxv/5x7Mlfn8XnCuQb8l4Izkj5FRksMpikg=",
      "url": "_framework/System.Threading.eci0fvui1v.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-KykJHUfS/oFlPFS3sHOtPpZL6VB62PlvTIBTTDJ+YwQ=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.b8cpj7rgnd.wasm"
    },
    {
      "hash": "sha256-IJMvdDVsdlziHo/bS69j2ywNOdnTsJUaXGR+Xg6p6mk=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.4nyqvrf2xd.wasm"
    },
    {
      "hash": "sha256-Ox2GAUNj5pWXKAy/SD4EXnQPNYeuMYtHttoY/A+gz34=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.lotaah4rsl.wasm"
    },
    {
      "hash": "sha256-h9ZOA20tz38ZUJxe+NHALums70hYR5wPYf6oqrrHN+Q=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.vaggo630fo.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-CETexI6WTUIKwegHrcYwB7rtam1xVyjQRuuK3BKTh/w=",
      "url": "_framework/dotnet.06nfpqwfum.js"
    },
    {
      "hash": "sha256-OQjCcXLGQBveA6QsGOAu/d3/rWHF2/H3gWe3knv6GzQ=",
      "url": "_framework/dotnet.native.3xqirttdq4.wasm"
    },
    {
      "hash": "sha256-ATkUC+Ee0svETG5wjFVr7gd0czmGdSzR0CCl87sRpys=",
      "url": "_framework/dotnet.native.n6lj5gz59d.js"
    },
    {
      "hash": "sha256-jCsbbdXoVd1zzGc0fQT2sz4mKuv0ANdurPVGo5Sc2jg=",
      "url": "_framework/dotnet.runtime.0j6ezsi0n0.js"
    },
    {
      "hash": "sha256-RdCT4sWYjuDb8iLISyPNv433B3T6rEDxyfQlB3Za7PI=",
      "url": "_framework/netstandard.jm5damrn2q.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-hozrjjpDVD17KQN8kHQoAnbcBesbx5em1R9auPdZydI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-gYGp1e+rn/jn0tovVD73BTWuvxqOZaqpZ3Dmx6kuI50=",
      "url": "site.css"
    },
    {
      "hash": "sha256-flnsJUUWBgPqNGDuj/cXuR6ssRYtIryLr9EOI5ol1m8=",
      "url": "site.min.css"
    }
  ]
};
