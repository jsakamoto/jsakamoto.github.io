self.assetsManifest = {
  "version": "rJsT/x8f",
  "assets": [
    {
      "hash": "sha256-AHn7kYyuEo98bV8uBp1gDXi3t2x5Ht4SfV8RB6LF6j4=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-Kfky1A8y9+ZwzlY43QWt+NQrv66OFcXP+yN4JDCOmuQ=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.9c7g4riq4n.lib.module.js"
    },
    {
      "hash": "sha256-IA/Nt4K44CJSHdd49ECdOkwXOCPXawJB84eO2A5qbyk=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-3pKTLyHO+S4KpvfUJF6OxoGvxm+DT7p4A4SXe2ocNj8=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bnjuj6nd91.bundle.scp.css"
    },
    {
      "hash": "sha256-CKLTKCQBt9kQwlseSBtAP0wPSJSFyNyck50wHcKOjG8=",
      "url": "_framework/CUIFlavoredPortfolioSite.4djkbi9kv2.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-u9GltKmZx2zmvMNrj+l4t58I8j57VM2BdhuZ6sepL2c=",
      "url": "_framework/Microsoft.AspNetCore.Components.9vme73jxo8.wasm"
    },
    {
      "hash": "sha256-/Krcako9Mpv4GvlEewrT2YO9FPBJK9IwKr23glz1ggo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.0dvl7nie9f.wasm"
    },
    {
      "hash": "sha256-IQjnLtASSZsQH+L8Ub3Ps6S4CGPWSxM/WfrlfvD7OnQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.h87yjj9kpo.wasm"
    },
    {
      "hash": "sha256-RNxX3+tcwTBx6H8CMBpcmRrq5+i5liwlkI3KLbca8hU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.40g9jw3qix.wasm"
    },
    {
      "hash": "sha256-YuR1Ua7fx8h4qYtz5Wxnvs8FDHfUxawhtbh9vO5VcHc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.upc4jyhwyu.wasm"
    },
    {
      "hash": "sha256-b0WRY6wvN1gps3fsyA0YCjRrTy/WieiDtqPXzAA+jhE=",
      "url": "_framework/Microsoft.Extensions.Configuration.zrk1mwphtk.wasm"
    },
    {
      "hash": "sha256-KNiYRXQVIXEWNqAgRGRs80LC0IoxjgLSP0RQLMujUow=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.klayyvzsp6.wasm"
    },
    {
      "hash": "sha256-7qw19G31qW/NTH1oywq7gvky8kNjuDXSjnnt4ituSCU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.ulchpo6a15.wasm"
    },
    {
      "hash": "sha256-7K/+MzhoeLfCW7uHN9W/1Eh4AdMaLTHnlpR5Eo8dbdc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.w5sabu0248.wasm"
    },
    {
      "hash": "sha256-oxVIPLT9UCefcXkQjc/J2JeRWgNJ83FcE1RlQf9OPYg=",
      "url": "_framework/Microsoft.Extensions.Logging.lm3oi4yvhx.wasm"
    },
    {
      "hash": "sha256-DKT+DJmJYM5AIE3qYHdtS6NBbNpUhVznjDMUl9b3Z5c=",
      "url": "_framework/Microsoft.Extensions.Options.oloq50wm0c.wasm"
    },
    {
      "hash": "sha256-oHedHR/UR5CkgkVdzER+WUj2rtPZhByEgCbeO6nE3qQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.0g63xlpyea.wasm"
    },
    {
      "hash": "sha256-7USHw9Y7dLcn4jTAr1EV7/umQH5L/OqEm1J03T6nWBQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p9xut1ui7t.wasm"
    },
    {
      "hash": "sha256-JojRbFCnCFwSUcGOhnr6AJEVKARFbFg0L/pOCgUxZTA=",
      "url": "_framework/Microsoft.JSInterop.mg1r4xi68v.wasm"
    },
    {
      "hash": "sha256-wuaX65CmuhizX6VnTyoIM0Ui1bF+ZCY2fbz2rliNIZk=",
      "url": "_framework/System.Collections.Concurrent.ahdgxopfpm.wasm"
    },
    {
      "hash": "sha256-oRe6GMjb8JsCnTDDKPBFzC+rhOPzHtp6IgLcsTbaOhg=",
      "url": "_framework/System.Collections.Immutable.p2cakurtb5.wasm"
    },
    {
      "hash": "sha256-hB0qtoSLJ8G/lIbI1J1zZ4v1EGPfi8YNdCkgQB4eJfQ=",
      "url": "_framework/System.Collections.kas5wtt98j.wasm"
    },
    {
      "hash": "sha256-KCQgm/zYGlnda/+V+Un/W0NVM6WLV70IQ/opp4osHSw=",
      "url": "_framework/System.ComponentModel.k1y23gmxdi.wasm"
    },
    {
      "hash": "sha256-oQYgQv89/UjmY6snm7ZocoQPxZxigHHtGGUQN0/hVmM=",
      "url": "_framework/System.Console.n6v2znn3bm.wasm"
    },
    {
      "hash": "sha256-pVPibSFYtTSm1Nar+eJCBxDvIQOZvTGIS9cxtAwB/c8=",
      "url": "_framework/System.IO.Compression.npso9jv9k9.wasm"
    },
    {
      "hash": "sha256-ZpXgbfWvJiasKGQVUNQEgr7qToY3RpfxsduTNlHRmWc=",
      "url": "_framework/System.IO.Pipelines.u3txdvdmvt.wasm"
    },
    {
      "hash": "sha256-WCtlXsg52V722v1KLeKZLmpmJC5XVr+sCqmujETO9sM=",
      "url": "_framework/System.Linq.gylafipvhk.wasm"
    },
    {
      "hash": "sha256-k/YbJu5NTt9pCgo6NYHrbnYJI9BGgoX5YP1RvXUBNNE=",
      "url": "_framework/System.Memory.re4l5quhay.wasm"
    },
    {
      "hash": "sha256-N26WLAwAqpRAtr19DpDnGVZQGmuRJuVGhDiocnbtObs=",
      "url": "_framework/System.Net.Http.35wi3ips5w.wasm"
    },
    {
      "hash": "sha256-pSjQdFkdtQTSQMK79roQx01zlZmz5JwQPn9LrakEmjE=",
      "url": "_framework/System.Net.Primitives.rkn082xkb5.wasm"
    },
    {
      "hash": "sha256-/fB7rr221fnU2kSThkkeqXQm9jHZQqKrtPFT+ZEUQJ8=",
      "url": "_framework/System.Private.CoreLib.n3gy9s72h9.wasm"
    },
    {
      "hash": "sha256-8G36VnWlPy9/CQONnGzExg6iJiVEFgJMmJdD08EMKds=",
      "url": "_framework/System.Private.Uri.sl6635jfwo.wasm"
    },
    {
      "hash": "sha256-vEx1NrY36YSsnVgYDIfGAK1JjPHrBQHkA7rLCLdDNu0=",
      "url": "_framework/System.Reflection.44fre0umz8.wasm"
    },
    {
      "hash": "sha256-rjQ5QGE+oiRN67mNhu71ooEHeniqLObcXAIF3NylizQ=",
      "url": "_framework/System.Reflection.Extensions.axgcc2sb50.wasm"
    },
    {
      "hash": "sha256-ToKNJzw3OEe37df6Mch8vpe8ayQZ3GsG+BIxyI7v0Xw=",
      "url": "_framework/System.Runtime.Extensions.aaovddrz7t.wasm"
    },
    {
      "hash": "sha256-lid9XdYjOLBMxt65anhgxOU/RtzuBUBGgMpOb9MGIBM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ms1astds5n.wasm"
    },
    {
      "hash": "sha256-KHg93dN15CpA+sJ/IExkM4cifzt/3cgeMVWGCxYsse0=",
      "url": "_framework/System.Runtime.czriyaxdca.wasm"
    },
    {
      "hash": "sha256-k2QvXX3TDa12tTiqCEEWZvFAFYfzBsTm30irZNW26LY=",
      "url": "_framework/System.Text.Encodings.Web.vlo045nbkm.wasm"
    },
    {
      "hash": "sha256-zFTYfreW/dMZG7Qf/OJvfaoDc0fFF0WW4GpXBPWpxkk=",
      "url": "_framework/System.Text.Json.cwwxg0qmpr.wasm"
    },
    {
      "hash": "sha256-DEUoajcWA70zRutk8OlQK3lS3OOYL1CXH+rCWLkzdXU=",
      "url": "_framework/System.Text.RegularExpressions.4mv48dfe01.wasm"
    },
    {
      "hash": "sha256-7hGi8f9FymUAoMrHMITYpSbC1yTOl2kv8K7K/PjAKKk=",
      "url": "_framework/System.Threading.ah88duxjw4.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-KykJHUfS/oFlPFS3sHOtPpZL6VB62PlvTIBTTDJ+YwQ=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.b8cpj7rgnd.wasm"
    },
    {
      "hash": "sha256-f4LpyqjBWc03Q3fjea9z4gVidvDE55VMMY9WbsAGHOU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.jry656higl.wasm"
    },
    {
      "hash": "sha256-yxmijHoIMG2sOdxMexImmbEOTYDED3ERqP6exA/qsYM=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.hhcg7r9wws.wasm"
    },
    {
      "hash": "sha256-h9ZOA20tz38ZUJxe+NHALums70hYR5wPYf6oqrrHN+Q=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.vaggo630fo.wasm"
    },
    {
      "hash": "sha256-gLclHeNSSkXzJUjUq0xF9qeHPzoR4D2tDS8e+ZZ1XT0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-zA+JRxiD9EB0q9Ux7DrdyEpxHYxMAE2LwVXYdlTVi9k=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wUcvVDEaj7E5j1TJqfcQrAa6D/16M0uvj643CTzR12M=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-pb79NIMCeeXqE1Oq9naZisX/QSweZ6vMe3jNYTZSj9I=",
      "url": "_framework/dotnet.native.7hbtikcmxz.js"
    },
    {
      "hash": "sha256-hrH+WsB4UVsX9TxhqtaPP7RAeb9MpLR6ebNQPbEXlbk=",
      "url": "_framework/dotnet.native.a74dnlrfop.wasm"
    },
    {
      "hash": "sha256-VKLjlMarxHvjJjycTYhSgQF0RrEcXY0tznNAixAE9oI=",
      "url": "_framework/dotnet.runtime.gbd5bg60a0.js"
    },
    {
      "hash": "sha256-SvzQMF1zw3jPWuPkCZJOLOzt0Q7PVB5Qb50GY9xO52Y=",
      "url": "_framework/netstandard.ix8ieuk7r0.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-tRR7v6ZqfNVt4+aFOcEJrxXgZY/QUg9lcVUseqpn0Ag=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-XstODeHpSfApNv74N2EjSbPos8GR38PcxhBEt9rigMA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-RBUikAEI4NQnEO55CIYdZvR1FONxzbgclc9+WG6Pj2M=",
      "url": "site.min.css"
    }
  ]
};
