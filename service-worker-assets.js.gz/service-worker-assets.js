self.assetsManifest = {
  "version": "WvLCW2js",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-yXN40g8pYp2eufc7T4BysaEKwjlOOE+cOZ+wj/2Kf04=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-x4hAHFuJ3tW/7yWCtqmsEpNxjFRKmBqhgcfFDp/2GMc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-xnGdwzkKBNB9AVBUmJhuorDlgk/UU8fFiuQlJ5jVrNc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.2drl8nn3fe.bundle.scp.css"
    },
    {
      "hash": "sha256-/Je8iZIzqqOl0WWbmn8bZ+6VxANICel94ROiq5A24as=",
      "url": "_framework/CUIFlavoredPortfolioSite.caldrkne3v.wasm"
    },
    {
      "hash": "sha256-Foe9GFjf90oQR41C8LQewt+QjFVVcjPFJ2oaa/5BZm8=",
      "url": "_framework/CommandLineSwitchParser.m4vm0sxx0r.wasm"
    },
    {
      "hash": "sha256-lYKmfxpMUDNiCKVw4h1Jrxm44Nvf0ODiZbOhYtSvbFs=",
      "url": "_framework/Figgle.9n58c2629i.wasm"
    },
    {
      "hash": "sha256-paILXW8RUR0F/Cv45v59D8jQaMa5paPgcnTS5UdhfuM=",
      "url": "_framework/Microsoft.AspNetCore.Components.5kts2fcyjq.wasm"
    },
    {
      "hash": "sha256-2rd/2BShIR/UQlUMUSF+CndtZMfKunfPJbhj/pgCBug=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.u67bzr04bl.wasm"
    },
    {
      "hash": "sha256-1Lvqu+mrxlPgFSYb31+QYUeltr0h2gy7+CvbhLk5dg0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.03swifgw4d.wasm"
    },
    {
      "hash": "sha256-ly/n4iZDBjUPNdMaxep5EiNkREMtRQsysU55QyZluLI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.3dw3x6pdpv.wasm"
    },
    {
      "hash": "sha256-XA9m6IfRO75pk4JQB8IYRj6YsUxEzwHZMxPsTW/kgmM=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.k6zdkamna5.wasm"
    },
    {
      "hash": "sha256-t1krLjRsdGcx5YuIEHb0C/rtL48ax1sy/yxfK0FY0/g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.31hizcgud1.wasm"
    },
    {
      "hash": "sha256-c6RIdnACQ6vMevYas2yKebN09PdRsZBqoE6crJRyO4g=",
      "url": "_framework/Microsoft.Extensions.Configuration.hr36b6kwwx.wasm"
    },
    {
      "hash": "sha256-SFsYNfQOPGG7vC0shoOXkUUCUJbskWjYqmd2tZ7/xOE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.weu3s7529j.wasm"
    },
    {
      "hash": "sha256-Th1/h0/2jZJM3l0M8sdRCS2hV6cgaojYGRqqBzScqjk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.mal6wzi3sz.wasm"
    },
    {
      "hash": "sha256-jMB6pEnu2pTB2S6mQQ0uCxqS0sIHT9A99Cp5uc2oTTc=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.44ew0otwut.wasm"
    },
    {
      "hash": "sha256-7aTOvSlJBJZbZW3IrUSsXZchN6UkHkuPME0SBymQ9KQ=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.lmop8t03o2.wasm"
    },
    {
      "hash": "sha256-zfFktafaoECKaBmI+e4GcaMOfax/ATmCmUQiFNes7XY=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.ryx1cwi229.wasm"
    },
    {
      "hash": "sha256-iO1J1Nznp1iduScsU0PGPoNq+G4eaoYr3FI0nw7nBKw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.svc9hme3sa.wasm"
    },
    {
      "hash": "sha256-ngmNT/swohM2/y5XLxpNqpyU4QdLRyEjntc17u3kD04=",
      "url": "_framework/Microsoft.Extensions.Logging.ukvv0itkpz.wasm"
    },
    {
      "hash": "sha256-UyCDFtky+wMI4h92jKxkMRROINP+xzb1r9TWjNKHygc=",
      "url": "_framework/Microsoft.Extensions.Options.nzpzmvkbyk.wasm"
    },
    {
      "hash": "sha256-DfFqpVSQ1ckOCaKNPfQ6VI62N/4oIcMA5fsrf6Z2O/s=",
      "url": "_framework/Microsoft.Extensions.Primitives.5aiedkezdb.wasm"
    },
    {
      "hash": "sha256-SZTzekEChF1w70iT6K0yI9NTTmRGAHuP1HXxer1avTg=",
      "url": "_framework/Microsoft.JSInterop.9gkj2t5yap.wasm"
    },
    {
      "hash": "sha256-7Bqq0bF5F32XF7oSiyqSOjDCZ8xaH1hhyObRbu2sBjk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.w5cug3t6gj.wasm"
    },
    {
      "hash": "sha256-HKixfXxsV/CuIphtr0UxgySNzPccSeTM3nebUE2m2LA=",
      "url": "_framework/System.Collections.Concurrent.096drj5a56.wasm"
    },
    {
      "hash": "sha256-2e3CVGi5gVpJJHJy9rX74vSdbWiunuPjYo1eOkysizo=",
      "url": "_framework/System.Collections.Immutable.hion2440c7.wasm"
    },
    {
      "hash": "sha256-Wg/MGLP6ZJfhH23AhRBx/K9sIIFBncw6oYgSR7nYzC4=",
      "url": "_framework/System.Collections.qn9ncd8obb.wasm"
    },
    {
      "hash": "sha256-pnFIHNc9sUWKlYmDusPDOaTd6fNcc86TwdK+osBi9mo=",
      "url": "_framework/System.ComponentModel.6ptk3ydl3g.wasm"
    },
    {
      "hash": "sha256-GvdvbzrGmNWjovvxbpuZRp88h+tiZnu+ny+fKG7xvek=",
      "url": "_framework/System.Console.602zwxhz1k.wasm"
    },
    {
      "hash": "sha256-rvn4ycKCrAq91O5GYKVX+OJEBbu39y0lHszIdbs/3u8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ikbfqxmxpq.wasm"
    },
    {
      "hash": "sha256-Axz+7VftuuI7QgABnCJoAZLYhgONJvAf34+wcG1QCRI=",
      "url": "_framework/System.IO.Compression.fxtulh1sji.wasm"
    },
    {
      "hash": "sha256-q3LhkQnuOlczFORmUPj3ZEXihSqAROgfG/69H8oKyy0=",
      "url": "_framework/System.IO.Pipelines.f3fdtun0z1.wasm"
    },
    {
      "hash": "sha256-Hebttrplvq5610ISEospwKLmsw6l7p8nh9l2Sl9PsYs=",
      "url": "_framework/System.Linq.5a3mkmk1kh.wasm"
    },
    {
      "hash": "sha256-3yyUJ/WssZuNVtP9oMUO61KYW5FCOIGKLlXeBYqcREg=",
      "url": "_framework/System.Memory.d5ix9wxn4b.wasm"
    },
    {
      "hash": "sha256-z13w+ZUe7cFG1Vw09tlzNm7bFUWHfhtrdO6tMXU52R8=",
      "url": "_framework/System.Net.Http.7ic65lwl7a.wasm"
    },
    {
      "hash": "sha256-Q0w/W978zQJdB/Ha/hn9FUtxaOGxsuXgoDbXAGLNolE=",
      "url": "_framework/System.Net.Primitives.ruz38banki.wasm"
    },
    {
      "hash": "sha256-x24FURGv4y02yGwnZ2WSQzq+7Jdj+0r/D2jLrYceOoA=",
      "url": "_framework/System.Private.CoreLib.7g0mzcdhfg.wasm"
    },
    {
      "hash": "sha256-5S7XyCuBzJPvUSgA9E4+Pim2XBtiMdZR2N7OSLU9x/w=",
      "url": "_framework/System.Private.Uri.vj58nro71q.wasm"
    },
    {
      "hash": "sha256-9UVOp41tjedMYD2a2cb2ZJujLUyLO81a+aFAjw2w2UQ=",
      "url": "_framework/System.Reflection.97nq66n1h6.wasm"
    },
    {
      "hash": "sha256-5RTTdn3GCoiYVELg7zDwsGBmR0bkDO+3iqnJo2LC04Y=",
      "url": "_framework/System.Reflection.Extensions.b0t1ior51c.wasm"
    },
    {
      "hash": "sha256-XczxJ2VLcT0UeuHOU0pwEd4f52KsRKFGsMK8J7Qnsug=",
      "url": "_framework/System.Runtime.Extensions.tstee4ewjq.wasm"
    },
    {
      "hash": "sha256-6DZAMELTB7joEHfMd5cDdJtG1ZWDhRY72UznlZdMy5Y=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.geh48whgjd.wasm"
    },
    {
      "hash": "sha256-dIfL5Mufo8Tj2R0P1QTVUuoIGb5hyd3jFJdORcJt2L0=",
      "url": "_framework/System.Runtime.c8y11dqest.wasm"
    },
    {
      "hash": "sha256-RbtnkvKTQbKiRtxPbVl/+eSNlv8TTtJURt3/fTzmIA4=",
      "url": "_framework/System.Security.Cryptography.79jhhidzig.wasm"
    },
    {
      "hash": "sha256-8xarQDsH1CyG5zsA7dyAbHtSHVxHViLiYUoyK99fzVg=",
      "url": "_framework/System.Text.Encodings.Web.tgnlv4n0i1.wasm"
    },
    {
      "hash": "sha256-OqZhC7gNSVtzO7ZTQzgqVVI2TNefIO3lz1nyP8WirNA=",
      "url": "_framework/System.Text.Json.y6kc1ph8zw.wasm"
    },
    {
      "hash": "sha256-pbj5IW8XUDgA+2Tl8n2tG2baVTM0XErbYozJbbre0l0=",
      "url": "_framework/System.Text.RegularExpressions.dqfko5m2fu.wasm"
    },
    {
      "hash": "sha256-aXfnkpKKesoLVR2U+qerQE7L024lDAzloMbfxPZntCw=",
      "url": "_framework/System.Threading.5hws8r9gju.wasm"
    },
    {
      "hash": "sha256-a0HrSmY7BOMv31wjSVfWReWEEmdIxjFUAmXsmMXRMgQ=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.zmzs621edh.wasm"
    },
    {
      "hash": "sha256-rSnX8E60A28YMjTWZYoEAErKvFfCbsD+lTiLXciPzw8=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.lid1nuwyba.wasm"
    },
    {
      "hash": "sha256-6nSEs5V2VGYQ6LKQGrykvTsoNMqcKHx7uGOUalHERdU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.2ye5ebkuc0.wasm"
    },
    {
      "hash": "sha256-Qyrzd9+dq6ipeaD9gOv0kN4ygl7JuoAzNBWYLzT+dLs=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dswvi7pnin.wasm"
    },
    {
      "hash": "sha256-KqdT4BJgh8et0cNn9eYY7MXq5jyWbJctcqjCBuwCQ1U=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.afnpi90o3x.wasm"
    },
    {
      "hash": "sha256-imaPWSmmKhi3iJ4xvtxd/x7m6wkoaEofSRZ63HAQc4U=",
      "url": "_framework/blazor.webassembly.um4crbf0p5.js"
    },
    {
      "hash": "sha256-tvLztupMsLNGx9TQrHPVR5Goiu8E8vb8V2F0oHh04b4=",
      "url": "_framework/dotnet.64e5ku9fjo.js"
    },
    {
      "hash": "sha256-swNVx5lcZdF9qXo2LuCreF+QCcFEogIyOK6Li3Ov7TA=",
      "url": "_framework/dotnet.native.3k6q86gmnl.js"
    },
    {
      "hash": "sha256-lHII6cgCCnOo8hQnuwYtmKQWU3hNAYq7hppdNgvrPE4=",
      "url": "_framework/dotnet.native.wv7q3cdyc1.wasm"
    },
    {
      "hash": "sha256-wWGGlgbEekxdoQy3RZF5n9Mk+9vVSihDrSGY1OWHGO8=",
      "url": "_framework/dotnet.runtime.td1jw5cbij.js"
    },
    {
      "hash": "sha256-Pvbks7ajGCCc54hIQ+NwXMrx6KeK1t2wvUGIbcznT7U=",
      "url": "_framework/netstandard.y802ke5fbe.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-ry5/kz2U7wegC0+HZxkgwMwhiHdWGtOhAshFHlbAzIs=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-gYGp1e+rn/jn0tovVD73BTWuvxqOZaqpZ3Dmx6kuI50=",
      "url": "site.css"
    },
    {
      "hash": "sha256-flnsJUUWBgPqNGDuj/cXuR6ssRYtIryLr9EOI5ol1m8=",
      "url": "site.min.css"
    }
  ]
};
