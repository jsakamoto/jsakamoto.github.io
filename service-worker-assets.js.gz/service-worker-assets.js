self.assetsManifest = {
  "version": "cWAFFoNb",
  "assets": [
    {
      "hash": "sha256-IdQk7PSAjWg2nyye6IkiPavaxEFsMHTLdOGbicsmo7I=",
      "url": "BlazorWasmPreRendering.Build.9609fvaqjm.lib.module.js"
    },
    {
      "hash": "sha256-yXN40g8pYp2eufc7T4BysaEKwjlOOE+cOZ+wj/2Kf04=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-x4hAHFuJ3tW/7yWCtqmsEpNxjFRKmBqhgcfFDp/2GMc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-xnGdwzkKBNB9AVBUmJhuorDlgk/UU8fFiuQlJ5jVrNc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.2drl8nn3fe.bundle.scp.css"
    },
    {
      "hash": "sha256-8VWPBeQ2sjUWpCOki0f+INHGAY/QD3DJNWTAkbaV5hc=",
      "url": "_framework/CUIFlavoredPortfolioSite.1oxmu141hu.wasm"
    },
    {
      "hash": "sha256-Foe9GFjf90oQR41C8LQewt+QjFVVcjPFJ2oaa/5BZm8=",
      "url": "_framework/CommandLineSwitchParser.m4vm0sxx0r.wasm"
    },
    {
      "hash": "sha256-lYKmfxpMUDNiCKVw4h1Jrxm44Nvf0ODiZbOhYtSvbFs=",
      "url": "_framework/Figgle.9n58c2629i.wasm"
    },
    {
      "hash": "sha256-3M6/0XobgAB0R2cbXOqGY4vMMo43k1K4eLkc9EPCHa4=",
      "url": "_framework/Microsoft.AspNetCore.Components.46w8uvo9d2.wasm"
    },
    {
      "hash": "sha256-83MZD44H71IwuR9O/ywovixNDnBlBNILLaI6ij4Tw8M=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jgq0ad9vh7.wasm"
    },
    {
      "hash": "sha256-bbgIpSElxdP54bEnHBC7oLcIdm/9qjrlLnn8WmqXiIs=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.z8lcd9eym1.wasm"
    },
    {
      "hash": "sha256-/Jk54D1KY5PHzM9dMnGK+L/e29BGWKMvya9e09ag6xc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s65zlvl4se.wasm"
    },
    {
      "hash": "sha256-wdso0nwXuU+Cq2P8IyCDlyDOdCgcqPiCtOlRdd2Cijg=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.jzkg2x7qhv.wasm"
    },
    {
      "hash": "sha256-ep+qNs7aVNWscDFf86qyUhPRzI1t18/CFHznABUoRb4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.yt5s0dcd1a.wasm"
    },
    {
      "hash": "sha256-sVjM3goh51UCzO721A7E9+4tI8IpuU75ich19epJqzc=",
      "url": "_framework/Microsoft.Extensions.Configuration.t5mic3u3ts.wasm"
    },
    {
      "hash": "sha256-513k+NCeN57MvjnM1hkEFRasqlNqDXZW/eRlQthMm+A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.hi0mqvky21.wasm"
    },
    {
      "hash": "sha256-mro8NlezLvNPWZhyomBqqFNFWEmDB3EFLlmUcr8MP3g=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.qgwp6l964k.wasm"
    },
    {
      "hash": "sha256-bxbrpY2YsCSVCMsIcRGtsyzTZFDCOkF28N/S7Jvv710=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.53qylfq3cl.wasm"
    },
    {
      "hash": "sha256-atgj02+jR19hWvwBPjn3nzJ/bnCi1iW1NX2rnEQ65P0=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.a8g14ndnkm.wasm"
    },
    {
      "hash": "sha256-9VcgrXb+PiPyrTcxIe1L/cy7Z5ZWOur7GlJkoKubrKw=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.v3kxgx981t.wasm"
    },
    {
      "hash": "sha256-HV6fJRmEShA9ksgYWprRmXcSpcXIw7AnWZWfDhRBZiU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.li41xcu5eu.wasm"
    },
    {
      "hash": "sha256-AgTmezlMqJij0Yy1aQJLiQhAotbX2vxIRIyQFnm1Xpw=",
      "url": "_framework/Microsoft.Extensions.Logging.adaaldmj0l.wasm"
    },
    {
      "hash": "sha256-jVm4z5nwf8SNZeSxa29vyI0b5rH9hQW/1hX9BFAa7O8=",
      "url": "_framework/Microsoft.Extensions.Options.bm9jnizb53.wasm"
    },
    {
      "hash": "sha256-agsMLBVF+Vef250bG6pT6ciwsAGJN8sfB5mwP0QQ+gY=",
      "url": "_framework/Microsoft.Extensions.Primitives.2x3j6d09qy.wasm"
    },
    {
      "hash": "sha256-WpQ0U2tISP34jpdiX79T4oFB6TKkJ1e+z1V7suE3pxU=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ydv3erh2ea.wasm"
    },
    {
      "hash": "sha256-ZaHnDG8DREiYB4MqDoMKnWTZkW3kTeXvgRZGEyzJH6E=",
      "url": "_framework/Microsoft.JSInterop.zqd09ckiw9.wasm"
    },
    {
      "hash": "sha256-Y6/fsGDGUOROI80/zUwZp4ozXNFRhLNzjjkMYfA+oC8=",
      "url": "_framework/System.Collections.38wt3dbmw5.wasm"
    },
    {
      "hash": "sha256-/9SfWaxuLUczm3F7/08FK/gaYLJzJEBvh4IHSD2m8zw=",
      "url": "_framework/System.Collections.Concurrent.3vyi83uqfo.wasm"
    },
    {
      "hash": "sha256-b8TQV9XcVD0rjwmBOAIshT/3qmU99qDy2SSYimD/5Ok=",
      "url": "_framework/System.Collections.Immutable.nqb48ersei.wasm"
    },
    {
      "hash": "sha256-mLKUG1cG9C/ZPZSovkFXHa6wiprwGTdImyiW1f+RTO4=",
      "url": "_framework/System.ComponentModel.8064ms1ax3.wasm"
    },
    {
      "hash": "sha256-tgccE+aIGJhU58I5GyBcSvf/ye6dsUYyy03jxIo9+eY=",
      "url": "_framework/System.Console.y1rrav2slb.wasm"
    },
    {
      "hash": "sha256-Y827LOQFxVjJnFZDccx7WzhFTe65kTVZBUK+AIRt/Cs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.1vkw9msmtw.wasm"
    },
    {
      "hash": "sha256-ihGT+iTSUpCXqVe2jIaAEHaD2ZnOwsRulqoCzf8wv30=",
      "url": "_framework/System.IO.Compression.2d22mgilbi.wasm"
    },
    {
      "hash": "sha256-r7wKAS7oxcoJTy7tCLMnkWk3Wi2l93xuyn/ZG+KTfX4=",
      "url": "_framework/System.IO.Pipelines.vw5bymtycv.wasm"
    },
    {
      "hash": "sha256-tBT2mPZhsvN0vDGHrxGkZUZ/EHIQXtyw7ElhroWfRcI=",
      "url": "_framework/System.Linq.8nncelds44.wasm"
    },
    {
      "hash": "sha256-xTJF5Q4/1j3dLabtmKogdFxho+IgVWRAcfx2D9Kl/10=",
      "url": "_framework/System.Memory.zeulg0ra8x.wasm"
    },
    {
      "hash": "sha256-poVw3QJHt+ji5M8CNRJl6gUrtafbRfQORalrj+vNAdc=",
      "url": "_framework/System.Net.Http.evzjmq4a27.wasm"
    },
    {
      "hash": "sha256-yWuMjRhF2eWXzsgLFQPw77x+7wkHlUNRAms86zU1rcc=",
      "url": "_framework/System.Net.Primitives.rzv538arix.wasm"
    },
    {
      "hash": "sha256-KFVUrzVmnugyuAaTb8UjPr+U/L2OKL9stO/eehCxZwM=",
      "url": "_framework/System.Private.CoreLib.4d54t1cv92.wasm"
    },
    {
      "hash": "sha256-rh7+3Wy3leu9njEuwNiuPalX9kkczrCYw7Y3I9XdrUc=",
      "url": "_framework/System.Private.Uri.i8mrsfc1m2.wasm"
    },
    {
      "hash": "sha256-zBTngBNoWhANype2waOGbg6G0+xq+P2BGs7jkqn6tMY=",
      "url": "_framework/System.Reflection.07xfz3x72d.wasm"
    },
    {
      "hash": "sha256-XECZ1n1VIinhQYrbeAfK9sV3VwO7oOzp9zNcAVQMBQ4=",
      "url": "_framework/System.Reflection.Extensions.0dtk6q8kwd.wasm"
    },
    {
      "hash": "sha256-buUU0ko5/LS1CmHl1TzPmyiv5YNZuUiYOu7bGbCDHw4=",
      "url": "_framework/System.Runtime.2cmmkfdco9.wasm"
    },
    {
      "hash": "sha256-XEgWE45ZtW7odrYoI3YzlPNrrJXlQhLZ/Vh2DW5LZYc=",
      "url": "_framework/System.Runtime.Extensions.8f8kkj987g.wasm"
    },
    {
      "hash": "sha256-xq0EdDisxJjHFB3HsOivMO/BRYE76KkWvpTk/niTZ1k=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.m1gwpwsdcd.wasm"
    },
    {
      "hash": "sha256-z802q+3oYIj5lG7hUa/0K0OgDc9W4HY6h0SsiP8QnmA=",
      "url": "_framework/System.Security.Cryptography.d92vdmp9jw.wasm"
    },
    {
      "hash": "sha256-JAx/tHR6fRy+a9/S9CzUSP8U6MwMIQusOkTXzDZwya8=",
      "url": "_framework/System.Text.Encodings.Web.4ajl7esew7.wasm"
    },
    {
      "hash": "sha256-gIQEgRlvZ/2MERxA3xRmZsy5UxJJwuTR5gR+YUhnLD4=",
      "url": "_framework/System.Text.Json.wczysyv55z.wasm"
    },
    {
      "hash": "sha256-EB2fAlomwx/LrXAcGfNt5VBBekc3CdSYxctm0RmMQnI=",
      "url": "_framework/System.Text.RegularExpressions.ou2u1idqwn.wasm"
    },
    {
      "hash": "sha256-dnOF8emee73rWIBMzEuLJkgu8WnBwkVmNJ3209rcnhY=",
      "url": "_framework/System.Threading.yerbdkvhzq.wasm"
    },
    {
      "hash": "sha256-a0HrSmY7BOMv31wjSVfWReWEEmdIxjFUAmXsmMXRMgQ=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.zmzs621edh.wasm"
    },
    {
      "hash": "sha256-rSnX8E60A28YMjTWZYoEAErKvFfCbsD+lTiLXciPzw8=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.lid1nuwyba.wasm"
    },
    {
      "hash": "sha256-6nSEs5V2VGYQ6LKQGrykvTsoNMqcKHx7uGOUalHERdU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.2ye5ebkuc0.wasm"
    },
    {
      "hash": "sha256-Qyrzd9+dq6ipeaD9gOv0kN4ygl7JuoAzNBWYLzT+dLs=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dswvi7pnin.wasm"
    },
    {
      "hash": "sha256-KqdT4BJgh8et0cNn9eYY7MXq5jyWbJctcqjCBuwCQ1U=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.afnpi90o3x.wasm"
    },
    {
      "hash": "sha256-h5BykV52WXDQQYSSeQYmnw2hLafu9fcAvqRQUCbYr2Q=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wK4d75N7t8qDNB2PXHAvew2pZnWUklx2XJPmmlACEsE=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-OgHgrTOZpusRTThIIiQKrRuQgULwFtPupE8hDX7F28E=",
      "url": "_framework/dotnet.native.a07v8potky.wasm"
    },
    {
      "hash": "sha256-yZpM0L7BsZqnPtJSJhjQuio4fc+53l3sd2xl/1V8Hfw=",
      "url": "_framework/dotnet.native.n84z54z2ov.js"
    },
    {
      "hash": "sha256-OGdJqUg/TKNiEWrbtZYHLEgztG9PgriAi1g0ExEKpa0=",
      "url": "_framework/dotnet.runtime.okxdo5zwwj.js"
    },
    {
      "hash": "sha256-sTXaSXmZpHenC9zFOxrZcrjYfLq/W264m2hMB2YFCUM=",
      "url": "_framework/dotnet.vsg137ytwo.js"
    },
    {
      "hash": "sha256-8n1ToQ+MTKnbDgPrc7APmtXlWftJcAmEDL2Z01/GNWA=",
      "url": "_framework/netstandard.yrulbqaf2s.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-L74lgkwVZY3OjrzYqbPDUjFMjxckpbJC8wfb3xW/sas=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-h+Frw3DrGQV4d9+Vk0DQ7hWgVkoi5ZSLK1scn/n1uIA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-BBwCxlx+/cC76bWkXY1Hn91b+/7EsuZuEzAV87+vBbE=",
      "url": "site.min.css"
    }
  ]
};
