self.assetsManifest = {
  "version": "36AVAE0A",
  "assets": [
    {
      "hash": "sha256-UwezpSZ5U6y5SoCmStNG9ekksy9a7X3WUO1Q0dwmEZ8=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-Z094C6tvTOKvix221ZuSPsaaNvGOp0XKqThmB4vfuOA=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lib.module.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-FusWOhPOKkLq10+x/UFtqpm/7B66OiSZdnFf1FsNKa8=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bundle.scp.css"
    },
    {
      "hash": "sha256-5PNWvGnpg/Ct5xFKMBsorM0ALerZin6BJ/Nu0Ga+R34=",
      "url": "_framework/CUIFlavoredPortfolioSite.cwhyh3ijv4.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-fVp5mOnHg8OvSr8CbokwCZQCufzMJsQI9riEfcMu0v8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.nnv917kd19.wasm"
    },
    {
      "hash": "sha256-/u5AsI2N3AdteT8rBNt+wU+YRHUOOXNOf1WHyQMNid0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.ijg9nn0sxe.wasm"
    },
    {
      "hash": "sha256-SYbcjxsItiH4voXM8rVRDQKl2h5TO4zapLaNArsaDAE=",
      "url": "_framework/Microsoft.AspNetCore.Components.vy1rbjyoyp.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-iQgVQgb3ha7FM9CUTP2T1Wpy+Z9257WhA6VrAdfd+Ik=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.n4hza34t0e.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-JwQhgiYmZimu0RwbvAJ9+AINDGVLaEnkOVrKEmgK54M=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.5dggl4gue1.wasm"
    },
    {
      "hash": "sha256-j5USfH7lIqpnRGZ6PS65d5BJSYQSUM8b4rUJUvUNXAc=",
      "url": "_framework/Microsoft.Extensions.Options.v4m2lt3b0a.wasm"
    },
    {
      "hash": "sha256-SOV/buK8+b547bCGV72fveEpbdwQKkvc60CYQA4qIt4=",
      "url": "_framework/Microsoft.Extensions.Primitives.8gcpmtr73m.wasm"
    },
    {
      "hash": "sha256-2+ztdPWvZucphCR0wmJIb0Lkd7/8Cb7F9xu546fvrAE=",
      "url": "_framework/Microsoft.JSInterop.3afqt8so3k.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-QOq837hO8NN9lLeVUzA+Zf+fUXlTL4EFys3Ba/olB9Q=",
      "url": "_framework/System.Collections.Concurrent.kz48na4grp.wasm"
    },
    {
      "hash": "sha256-2m/bYtO5R/XqA9v6Rl57gh344zir6A/Tmmy98txyfRI=",
      "url": "_framework/System.Collections.Immutable.qrgd227ceg.wasm"
    },
    {
      "hash": "sha256-RUfhumPcESudk8k/yN65Ost7hFcs7boiXCBxTCPSdMg=",
      "url": "_framework/System.Collections.rszapn3lhq.wasm"
    },
    {
      "hash": "sha256-ggftgc5cU4VTXzEcEGBVl+OtnGRGmlZ9ZZHkKMVLxYw=",
      "url": "_framework/System.ComponentModel.28u698euyz.wasm"
    },
    {
      "hash": "sha256-vqz+iN8SxxHLSqkJTNkKUh887JRKuY05oqHcFLSLhm8=",
      "url": "_framework/System.Console.2ctzkww75a.wasm"
    },
    {
      "hash": "sha256-ig9j6FsUX82TiVY0DT2VMHG0acmzh1QDd/gP5TWdyjw=",
      "url": "_framework/System.IO.Compression.uq75qcn7hw.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-2ufEIJWwj8OQi6owShM4CsfL4gxqAcnfUsI3tiL7YXc=",
      "url": "_framework/System.Linq.e6w52t53xe.wasm"
    },
    {
      "hash": "sha256-I8VWyuQW6vuwxP1LYANSKzKmP5n224wuKHyNCrx5cn8=",
      "url": "_framework/System.Memory.d8bwii2l0b.wasm"
    },
    {
      "hash": "sha256-PuONLjVT+RdY6SF7OiLiUWRgrDDy0Yhg/3WsHIKKNh0=",
      "url": "_framework/System.Net.Http.if1wca2g7s.wasm"
    },
    {
      "hash": "sha256-S21BwAjdSlZYujl9gymU48gTnFdfUyHO8N4chrKPCN0=",
      "url": "_framework/System.Net.Primitives.rcgya37loz.wasm"
    },
    {
      "hash": "sha256-sagGSVN5CssU5t0IJMdKMYznGlI6r7/y94wzJ19ltqQ=",
      "url": "_framework/System.Private.CoreLib.9q0g5j3jpf.wasm"
    },
    {
      "hash": "sha256-Y2AKAJaxW5OpWRULlYoaH/BL+nNs3Cgh4xcUmCgMYnk=",
      "url": "_framework/System.Private.Uri.dkcc1hhxoo.wasm"
    },
    {
      "hash": "sha256-yPdTGuZb5P3kbozPRn4IocbgZE2ouC3vCyc9JQ+6VQ8=",
      "url": "_framework/System.Reflection.Extensions.wuql52i8e2.wasm"
    },
    {
      "hash": "sha256-SV1Flk9k8M8ANjbdLmR5+VSmWmNBisbWKMALhQ/3ff0=",
      "url": "_framework/System.Reflection.ldm4zse1e6.wasm"
    },
    {
      "hash": "sha256-rw1GwaiqT4kY/TMISFmuQ5dxkn3YxR7pQZXfIzGpFa8=",
      "url": "_framework/System.Runtime.Extensions.33segqph2k.wasm"
    },
    {
      "hash": "sha256-VS4CSyZJNRAj+SrJqgbXBFWlGMlNDgM4rbwJ6gTH5qg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.x50649m5t2.wasm"
    },
    {
      "hash": "sha256-xo+CDfAbIabvztQwYZyTMoA2zTMjyHcFo5eN7Q8E08E=",
      "url": "_framework/System.Runtime.iiakq53peg.wasm"
    },
    {
      "hash": "sha256-wywNMAD+mx599NMpSNIDIF6GIAS72kEphV4maF4vf3c=",
      "url": "_framework/System.Text.Encodings.Web.rm908lga5z.wasm"
    },
    {
      "hash": "sha256-G37TuEGwsS6wf0CJ807NrpsQyt15xqfhCWS8PY532Ao=",
      "url": "_framework/System.Text.Json.p3m8k3yfgw.wasm"
    },
    {
      "hash": "sha256-QLqtOtTv8fw2aFCcQ6rkn4ZrJg+cq9ehDLguLki0z6Y=",
      "url": "_framework/System.Text.RegularExpressions.o26axn8m28.wasm"
    },
    {
      "hash": "sha256-aIx5rnPej8hcc5oeMQsaB4zHJDz9pje2l1AYFmX3mMw=",
      "url": "_framework/System.Threading.cjrcei28ym.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-NYA/dRWBU0sE9br6E2oXiQ5WHD3AAwXZvE+6h5pefDY=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.19vcfez3n4.wasm"
    },
    {
      "hash": "sha256-weCJXWDU5zdPFFtz1l8hFf5cGyJf7Njav44MN3D8lqg=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.9a5840lppl.wasm"
    },
    {
      "hash": "sha256-rLxY8GcXMc+DtDtierw+tYTWjmMqRtyqbLVk7ApPs8A=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.c6rjv9zjd9.wasm"
    },
    {
      "hash": "sha256-DfVvM/mfswFj4vsQDSsiVHFtPpHGPp+GMGzzCpy5wxE=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.9tj3m60764.wasm"
    },
    {
      "hash": "sha256-4WhB5DKJ9DkuDuPXCFhJ7XoCOmGeGLjXxzOAVzur4iQ=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-jTN+M5y4KxQtThVwQindRUSW9TWfht/ZT+LpOkfGQrQ=",
      "url": "_framework/dotnet.native.1j2fdbcam2.js"
    },
    {
      "hash": "sha256-ti319DTF7jUKf4rDDiDVlui02mll/OINkYMlLjoCCdk=",
      "url": "_framework/dotnet.native.ipqu3a8myt.wasm"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-386EuAJSs9PhWPMWISUht7c2bhdM4m/BkQYrctVxBXs=",
      "url": "_framework/netstandard.lnplw724qr.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-tRR7v6ZqfNVt4+aFOcEJrxXgZY/QUg9lcVUseqpn0Ag=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-XstODeHpSfApNv74N2EjSbPos8GR38PcxhBEt9rigMA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-RBUikAEI4NQnEO55CIYdZvR1FONxzbgclc9+WG6Pj2M=",
      "url": "site.min.css"
    }
  ]
};
