self.assetsManifest = {
  "version": "kNw0D+xN",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-yXN40g8pYp2eufc7T4BysaEKwjlOOE+cOZ+wj/2Kf04=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-x4hAHFuJ3tW/7yWCtqmsEpNxjFRKmBqhgcfFDp/2GMc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-xnGdwzkKBNB9AVBUmJhuorDlgk/UU8fFiuQlJ5jVrNc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.2drl8nn3fe.bundle.scp.css"
    },
    {
      "hash": "sha256-f2Vxx8zSgyLKoaIB6KfjILdwamKmPLpEPp9Eqxm+7Fc=",
      "url": "_framework/CUIFlavoredPortfolioSite.lry2qtl9xs.wasm"
    },
    {
      "hash": "sha256-Foe9GFjf90oQR41C8LQewt+QjFVVcjPFJ2oaa/5BZm8=",
      "url": "_framework/CommandLineSwitchParser.m4vm0sxx0r.wasm"
    },
    {
      "hash": "sha256-lYKmfxpMUDNiCKVw4h1Jrxm44Nvf0ODiZbOhYtSvbFs=",
      "url": "_framework/Figgle.9n58c2629i.wasm"
    },
    {
      "hash": "sha256-LX4xlkGindaJU5P0wCzv46LyHv3fgmtP2my3Erm1N8A=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.3gt36d3mtl.wasm"
    },
    {
      "hash": "sha256-aUQ+ct15ggh+3N/HyOatD4Z8ZwH5dt2l59OxD6czcR0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.1690eqi6at.wasm"
    },
    {
      "hash": "sha256-RV0nZetcAeDnnEjCpycpVBDZPTS4mW0XC5KN788ptIs=",
      "url": "_framework/Microsoft.AspNetCore.Components.bcc98lgu5x.wasm"
    },
    {
      "hash": "sha256-D2o1/HOXkVYigs/5P+Txk0TngqvmWQrZ4vTt3C2Z8v0=",
      "url": "_framework/Microsoft.Extensions.Configuration.3rcy11fv5e.wasm"
    },
    {
      "hash": "sha256-/hMdE4R2fxI2OLHKLzrSPdmwjrqQVJsReDU5aziYDuk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.qt9pmg8ayl.wasm"
    },
    {
      "hash": "sha256-Nq3tHbeNw/wveCsh5yOEZ0rWGaOAqVOpSo+4Yxtf5QU=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.6c4x5pjjbx.wasm"
    },
    {
      "hash": "sha256-wlWy0Vj7xrrx9djWUM+n2OhC0Mh7xV6exjqvi+L3XtE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6qp04h42hq.wasm"
    },
    {
      "hash": "sha256-LSNzrBoSCHBwgzdnGoNKcQNprzq7Iro4IoWxbfnCfEk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.d4dz2x1igm.wasm"
    },
    {
      "hash": "sha256-ROVkHFJYDp4rmV6E5HpR4tcr3goOhAzVbIXXyiaDhFE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.c2v4vssl8t.wasm"
    },
    {
      "hash": "sha256-u2m+5sqryfqiwRRw/Ta9itlXknVKESTp5sm+VFoqoLA=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.1tnz7j6try.wasm"
    },
    {
      "hash": "sha256-t7bmfrQ7+EekCXK0PLcXYE71WHoVqcYcodw+1GaaGPA=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.djdv3gh3lf.wasm"
    },
    {
      "hash": "sha256-ziaL1pGPCENfg9YOfzutZ6RvEPrBVco2N2OGB0EEFjs=",
      "url": "_framework/Microsoft.Extensions.Logging.q5s1ep92h5.wasm"
    },
    {
      "hash": "sha256-EmUvq4q21fMhM++9ctuivRL4e4py1GnE7ZcHdfjtYIE=",
      "url": "_framework/Microsoft.Extensions.Options.6j2tre0foh.wasm"
    },
    {
      "hash": "sha256-aKKS+29pT5Sb4kTE8PWy9elpT2e3Sof1gk57/9mroUc=",
      "url": "_framework/Microsoft.Extensions.Primitives.0em59tygmd.wasm"
    },
    {
      "hash": "sha256-wNfcQ2ukcMBX2nCXFw0BMNpQ1DvkuWqFox1YeHALwhU=",
      "url": "_framework/Microsoft.JSInterop.0wonuny57m.wasm"
    },
    {
      "hash": "sha256-3mN/FEMHJaWYe8X+O0bVwZnPIhH+cMWMcivsbAdnung=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.epdbmv5ijr.wasm"
    },
    {
      "hash": "sha256-30l5K7cHWJ1xTniLvhbhCOQJe9fBxOMmDAeSe+L3Imw=",
      "url": "_framework/System.Collections.3btua87ay1.wasm"
    },
    {
      "hash": "sha256-qSdNu7CvviA4TMgvAc8Iv+6pLakYO2DLacKoFLL983E=",
      "url": "_framework/System.Collections.Concurrent.94h0ho0fc6.wasm"
    },
    {
      "hash": "sha256-yw91Nvhl1tvdNgW+mSWiGiiIGG/mrnEsJm8UkgHEa2I=",
      "url": "_framework/System.Collections.Immutable.1196h362ky.wasm"
    },
    {
      "hash": "sha256-4zSlGNIS5IgMlBW7Yhkp3YliBTGukOOkyopWNjyeUNE=",
      "url": "_framework/System.ComponentModel.7v498303jl.wasm"
    },
    {
      "hash": "sha256-2T/RxJUM2HvXvwZexyyw9606OgQs6t2trAko+XagjoU=",
      "url": "_framework/System.Console.bbltbpsww6.wasm"
    },
    {
      "hash": "sha256-M9okbPel/MGlmi3e8jC6UAKcIZv3dlrXJPDSxoZ98vM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.lals3m1rc9.wasm"
    },
    {
      "hash": "sha256-WyWU5NnqR/I1wMD2ugvsPs425HKOJvtmN3ahPcCzSro=",
      "url": "_framework/System.IO.Compression.j2kjxqd4rn.wasm"
    },
    {
      "hash": "sha256-w4pgP22gtSQ0OzU2usVwDOboRSC87Rb/G4LTmFwcbfw=",
      "url": "_framework/System.IO.Pipelines.jwjwuoqi5r.wasm"
    },
    {
      "hash": "sha256-Z2lXvWdZYulDchNIfT19JwmrCvSAS2lXG35MjJzip+A=",
      "url": "_framework/System.Linq.3x0ntux6ur.wasm"
    },
    {
      "hash": "sha256-4smFOAYVpeMD93+XRIITKWLRBfcTipAqH1ESXJVK3D4=",
      "url": "_framework/System.Memory.6rhslr8uwp.wasm"
    },
    {
      "hash": "sha256-HMQII7SsNm1Fm64V7WZ2mi22xyxepie/JeITWV/snHI=",
      "url": "_framework/System.Net.Http.kaq46og9vb.wasm"
    },
    {
      "hash": "sha256-e5r5XINRuwIdISk1pEuAGVVZOIjLbG58pEVe/jMFWA4=",
      "url": "_framework/System.Net.Primitives.vzjtkj9105.wasm"
    },
    {
      "hash": "sha256-hd411Xpuo1ay7PDsiDoQfb9mTH2GdzqQVubHKP2j1aQ=",
      "url": "_framework/System.Private.CoreLib.bs0m09bglv.wasm"
    },
    {
      "hash": "sha256-Am4LNnypQSR1KuxF5vfc8PvzEGwirIFE/UInl9JtKT0=",
      "url": "_framework/System.Private.Uri.mn75o884m5.wasm"
    },
    {
      "hash": "sha256-DIamZHH8MF+ZMqJ9Obttx6ye3fQ343RVa6yV2PirQPo=",
      "url": "_framework/System.Reflection.Extensions.ksjj7i6dx1.wasm"
    },
    {
      "hash": "sha256-kGHsADIHcuFB2XHGOhQwsDnCflufaYtFolUeaFFgeHY=",
      "url": "_framework/System.Reflection.wwzbrzb76j.wasm"
    },
    {
      "hash": "sha256-JRsmynN9+FZ5WWGMBZjDwcfwT7wUA44dZhmwUtrPkYI=",
      "url": "_framework/System.Runtime.Extensions.lsaik0w2u7.wasm"
    },
    {
      "hash": "sha256-0R4F4bK7F9sieuDgNU4nR6asJddt+6DMu++WrXws54w=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lfyykq0gz8.wasm"
    },
    {
      "hash": "sha256-gFp6mVBmeLiBXX6t3gaJCSUJAzFPzKIzQ6h6EzxWCr8=",
      "url": "_framework/System.Runtime.oimq9aefhu.wasm"
    },
    {
      "hash": "sha256-x2LBHDXioCLLjxZ5hu94vqugJfDP3z+N0+VicRW47O8=",
      "url": "_framework/System.Security.Cryptography.1yzlseqrc6.wasm"
    },
    {
      "hash": "sha256-blj0tdFNJr6+FW5m2M8TglB+LzesggciYAJpo8l9MuM=",
      "url": "_framework/System.Text.Encodings.Web.671ilr9z75.wasm"
    },
    {
      "hash": "sha256-nK60xn/zXLToZwnSRRESvPWLkSUEr0RVFKfNY3IuGhI=",
      "url": "_framework/System.Text.Json.cy946437nn.wasm"
    },
    {
      "hash": "sha256-J+juOCieb+8kt1BAU0oihcaerXk+r8WBy6fBSth4Lro=",
      "url": "_framework/System.Text.RegularExpressions.rzm31otury.wasm"
    },
    {
      "hash": "sha256-NUS9QaiiBk2udRo2WavVUt9PKfEBoam2lkClNU7kXYg=",
      "url": "_framework/System.Threading.za4s7oneuv.wasm"
    },
    {
      "hash": "sha256-a0HrSmY7BOMv31wjSVfWReWEEmdIxjFUAmXsmMXRMgQ=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.zmzs621edh.wasm"
    },
    {
      "hash": "sha256-rSnX8E60A28YMjTWZYoEAErKvFfCbsD+lTiLXciPzw8=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.lid1nuwyba.wasm"
    },
    {
      "hash": "sha256-6nSEs5V2VGYQ6LKQGrykvTsoNMqcKHx7uGOUalHERdU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.2ye5ebkuc0.wasm"
    },
    {
      "hash": "sha256-Qyrzd9+dq6ipeaD9gOv0kN4ygl7JuoAzNBWYLzT+dLs=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dswvi7pnin.wasm"
    },
    {
      "hash": "sha256-KqdT4BJgh8et0cNn9eYY7MXq5jyWbJctcqjCBuwCQ1U=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.afnpi90o3x.wasm"
    },
    {
      "hash": "sha256-Pnl/1n2/0NhOSFOA5IOjMY6Z05FiNy8GH9bTuRfDBq8=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-R+K2s102TSNc/ahNNGlw0hs4o9kwKwhUWD9W1IQazOk=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-M/Qf1Cv9T2KskX/Mcz8EkvMzGNfnnwK8QJl9lZpxdyE=",
      "url": "_framework/dotnet.native.li7rxvlnx4.wasm"
    },
    {
      "hash": "sha256-tVin2jh630L2Qu44Osf8zPp7MUF6CBO8t0rfwh8tahk=",
      "url": "_framework/dotnet.native.nhlqgmt3ex.js"
    },
    {
      "hash": "sha256-lABkOE8bmlyS/B4yuy5pfOhCAWJCdpyu11ktH3I+WGE=",
      "url": "_framework/dotnet.runtime.0js0jvi2bt.js"
    },
    {
      "hash": "sha256-HAtmQR5AzlObYL203UMtFeDQzOeBMPsIfnV5bGtzKF0=",
      "url": "_framework/dotnet.s6f4nqzq3o.js"
    },
    {
      "hash": "sha256-4xIqNx5SANXGo+G6rA37fM3PUSHRIJcpkl/V3myojhk=",
      "url": "_framework/netstandard.luxf4suxkn.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-lrg0sM5FNG4DhWGN6EwDx5M4DeQYlf35duCdI8QZYWw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-gYGp1e+rn/jn0tovVD73BTWuvxqOZaqpZ3Dmx6kuI50=",
      "url": "site.css"
    },
    {
      "hash": "sha256-flnsJUUWBgPqNGDuj/cXuR6ssRYtIryLr9EOI5ol1m8=",
      "url": "site.min.css"
    }
  ]
};
