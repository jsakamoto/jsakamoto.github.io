self.assetsManifest = {
  "version": "JhdvIeRM",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-yXN40g8pYp2eufc7T4BysaEKwjlOOE+cOZ+wj/2Kf04=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-x4hAHFuJ3tW/7yWCtqmsEpNxjFRKmBqhgcfFDp/2GMc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-xnGdwzkKBNB9AVBUmJhuorDlgk/UU8fFiuQlJ5jVrNc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.2drl8nn3fe.bundle.scp.css"
    },
    {
      "hash": "sha256-lHeZIXunZmWMXWGWHF+qy6HmDKlPEcvv9iqt/Qu80t0=",
      "url": "_framework/CUIFlavoredPortfolioSite.4q42k8pbiq.wasm"
    },
    {
      "hash": "sha256-Foe9GFjf90oQR41C8LQewt+QjFVVcjPFJ2oaa/5BZm8=",
      "url": "_framework/CommandLineSwitchParser.m4vm0sxx0r.wasm"
    },
    {
      "hash": "sha256-lYKmfxpMUDNiCKVw4h1Jrxm44Nvf0ODiZbOhYtSvbFs=",
      "url": "_framework/Figgle.9n58c2629i.wasm"
    },
    {
      "hash": "sha256-ZhIyV3Eyu8s2bMYYXp08Vshlpcta/YVGw6lpFLaCrdQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.iptomw10ha.wasm"
    },
    {
      "hash": "sha256-LgA1RiFj8/jguQkOp637FWzGi5nsmpZD7X55QCpT55s=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.q6271idce0.wasm"
    },
    {
      "hash": "sha256-y385RPiYHFVPr43PFCuQvzfmciMHZ/8+lDBggacU0dU=",
      "url": "_framework/Microsoft.AspNetCore.Components.fbnjz8qvo7.wasm"
    },
    {
      "hash": "sha256-wqcgisCDM/xgZcR5dt9DEfXgCaHtDH6DcgrNqXpbTOk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.e5gc7lfkix.wasm"
    },
    {
      "hash": "sha256-xeuARd82/CCHd6Whea/RGyYoEuECGcmfTUnlSODb/Jc=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.b892901v62.wasm"
    },
    {
      "hash": "sha256-GxTmBaxW5MD3WA9RNeX4JluQzHYw9ILo5SPxWnK/UWY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x90ubd54wv.wasm"
    },
    {
      "hash": "sha256-P3KqNf7ruQbpdWzwdIyl4f/yRIzD1Xl0aiwL7Xz0XJ8=",
      "url": "_framework/Microsoft.Extensions.Configuration.txsxhz2pbe.wasm"
    },
    {
      "hash": "sha256-RL/oT0obZHZSXQGv2nEkqUB2HUwp6R5u/WNeDvYtOxw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.8n4fye26q9.wasm"
    },
    {
      "hash": "sha256-BDjPh3UlQse4bGBeiggPOzdcTQ/cMbBy1gLsQAOVUDs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.swy58oqmny.wasm"
    },
    {
      "hash": "sha256-tft0iwIOfxc85rMVRClonBouXYhABh5dLnHOlsDUaok=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.11l916n5jg.wasm"
    },
    {
      "hash": "sha256-UeCFfphZTLnuOZrMtn8mDJUrtlO27Xb42IiVAMGeJrs=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.na3kulwyx1.wasm"
    },
    {
      "hash": "sha256-TtCYJURVhlO9cWgiY+HbyVUD+33l2Hu20VGphQ4mtrQ=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.exg0uvu9gy.wasm"
    },
    {
      "hash": "sha256-u84f2H741zr8o+hBXVClXP23y1S4OXeZ1QeHK8HM3RQ=",
      "url": "_framework/Microsoft.Extensions.Logging.19kf52z63u.wasm"
    },
    {
      "hash": "sha256-Q+HiarsqwoGs/Zcw0VZnp3ytSj7p0rQqvYYFGjr4Qjg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.xf80k88rqd.wasm"
    },
    {
      "hash": "sha256-AW0/lz+G6Qq2GjfdbCOBp37KLazy0VtynrI+6a8f6h8=",
      "url": "_framework/Microsoft.Extensions.Options.folh7l7jtr.wasm"
    },
    {
      "hash": "sha256-L7Xo/t8AwCl3jDAxgg1dzgPMps2aw2a6xYXZel/Ct1c=",
      "url": "_framework/Microsoft.Extensions.Primitives.nyduzo79d7.wasm"
    },
    {
      "hash": "sha256-9b9UEEVWTp7L6htSboOO5k+ZXOZqpZ98WxP+I7PGqQQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nxdu237g5o.wasm"
    },
    {
      "hash": "sha256-rSYGB7Zf6YIYjqZ8cJpwbZaT1ms1hSuZa7o1ZeBjQCI=",
      "url": "_framework/Microsoft.JSInterop.xboq1yckif.wasm"
    },
    {
      "hash": "sha256-NzLS22GS2TKcqDp66u+oDTQ9qFh2HtUMGYtMBGKt2AA=",
      "url": "_framework/System.Collections.Concurrent.p4udsqvjgs.wasm"
    },
    {
      "hash": "sha256-rkWGKgqh3aPGO+8UMF/3W2c+tKSPT47koQK31oSK200=",
      "url": "_framework/System.Collections.Immutable.e9cxmao9m1.wasm"
    },
    {
      "hash": "sha256-0gMbJ2XMlbz+eA2uKzx2yoBQDTZiPKdfZc4iUVwc8Nc=",
      "url": "_framework/System.Collections.qpllzqvce1.wasm"
    },
    {
      "hash": "sha256-GrE/jEiGKsv26268RmQIKm632/JmA1JkGyHCCnwXwmk=",
      "url": "_framework/System.ComponentModel.eqzwy4mibs.wasm"
    },
    {
      "hash": "sha256-3n5lLz3gkokLC+zA7bPlk6kxIZXGtUDw5AaXHjD61/0=",
      "url": "_framework/System.Console.mmrk21xvyn.wasm"
    },
    {
      "hash": "sha256-1rW4AJ2nE0xFH565InY5ACTHSOX1OdgpMs54Fmrdze8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.eelitb7r19.wasm"
    },
    {
      "hash": "sha256-SntaOjsWOiOANQYEhkoIlxMtqU+tGprEkj7O5cbuofU=",
      "url": "_framework/System.IO.Compression.qn6gv437wl.wasm"
    },
    {
      "hash": "sha256-95SuLWYCWd1dHJs4mJWMFjPZnLe3u2vFx6DHa8FARUA=",
      "url": "_framework/System.IO.Pipelines.ztwn7ujnlo.wasm"
    },
    {
      "hash": "sha256-LsZVZVL3+oIBX5B0cTIeZHRSKQ1aJOQ89XR3p83rGu0=",
      "url": "_framework/System.Linq.u87i1w75mt.wasm"
    },
    {
      "hash": "sha256-LxQI78TvZvP7w4kWaZrGz0ARUgn0pRijUqFA4hOACng=",
      "url": "_framework/System.Memory.x4y85ufdfu.wasm"
    },
    {
      "hash": "sha256-Na0DX2KjHu2Y8/ZSQBKC5ZvZljf6frOqv41IwFe1/sk=",
      "url": "_framework/System.Net.Http.bcpunoejo8.wasm"
    },
    {
      "hash": "sha256-Z5CxIpfzLB6gZs7dDel2JEqcE/vvQg1AVOUVFHHQ3wU=",
      "url": "_framework/System.Net.Primitives.djq5qc19xo.wasm"
    },
    {
      "hash": "sha256-DhHIBNlLKS1aMz8+7EsQfGYIPv/jgIHNH5H/MV3c8d0=",
      "url": "_framework/System.Private.CoreLib.myzwba0tv4.wasm"
    },
    {
      "hash": "sha256-kKOnChmJEhZwphKiZBMR772S1KdRicEdK9oFrwpfHgU=",
      "url": "_framework/System.Private.Uri.0cec0s6yqn.wasm"
    },
    {
      "hash": "sha256-ojZqLBX6CH5WeG/KBpyx1c4VrNJY84O7idXRUsJ6vg8=",
      "url": "_framework/System.Reflection.Extensions.qiww6t35ch.wasm"
    },
    {
      "hash": "sha256-UYA1BtRkDeulJ93hwBN+H3lf7HiBiYQR/yvj10xyhqI=",
      "url": "_framework/System.Reflection.jr953fw94x.wasm"
    },
    {
      "hash": "sha256-KLLzxyxmQmRueYVkY/G/TTfEQDCqsoiiBFjw1F9HI3k=",
      "url": "_framework/System.Runtime.8cvynejpyt.wasm"
    },
    {
      "hash": "sha256-n+WP8YkcvL+WqqzkEMoyPYnTIfQwbVFvi204w+4lBQQ=",
      "url": "_framework/System.Runtime.Extensions.5zvq2x9wnh.wasm"
    },
    {
      "hash": "sha256-RAKqMWRjS2Zs6nwGm/e4YehZJIIupOpqcU3MTJ6Zzmc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.kotgcvu3u5.wasm"
    },
    {
      "hash": "sha256-81mcuVkdTa0wNa6oWyNx2e+TULvl3DElpPuQgzQIiQQ=",
      "url": "_framework/System.Security.Cryptography.3kehqjfuy7.wasm"
    },
    {
      "hash": "sha256-WtIq3jLfGRx8beAgp+Cw3L0Fvg/WDdQAGehP4HNbANY=",
      "url": "_framework/System.Text.Encodings.Web.iau8n4szg5.wasm"
    },
    {
      "hash": "sha256-nibUvz+/C0i4S1j04zBRdN/aNsXs/8YXCGX6nhUtP34=",
      "url": "_framework/System.Text.Json.6bxvbhtix4.wasm"
    },
    {
      "hash": "sha256-D34KqGAdvUKwt/dOcQmA0yL2AFIuewmyPkzdRAAK31w=",
      "url": "_framework/System.Text.RegularExpressions.5zcd3zromu.wasm"
    },
    {
      "hash": "sha256-JAOACbNyU44xCIcbIlFykyfw/JHaH32tlihhBRYgBJk=",
      "url": "_framework/System.Threading.w12v31yxs4.wasm"
    },
    {
      "hash": "sha256-a0HrSmY7BOMv31wjSVfWReWEEmdIxjFUAmXsmMXRMgQ=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.zmzs621edh.wasm"
    },
    {
      "hash": "sha256-rSnX8E60A28YMjTWZYoEAErKvFfCbsD+lTiLXciPzw8=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.lid1nuwyba.wasm"
    },
    {
      "hash": "sha256-6nSEs5V2VGYQ6LKQGrykvTsoNMqcKHx7uGOUalHERdU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.2ye5ebkuc0.wasm"
    },
    {
      "hash": "sha256-Qyrzd9+dq6ipeaD9gOv0kN4ygl7JuoAzNBWYLzT+dLs=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dswvi7pnin.wasm"
    },
    {
      "hash": "sha256-KqdT4BJgh8et0cNn9eYY7MXq5jyWbJctcqjCBuwCQ1U=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.afnpi90o3x.wasm"
    },
    {
      "hash": "sha256-N0nZnmhz3NA4zteM5TJMuhtyDqPSKDZKPCBbO6LahL0=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-HfDuzDlk7xdiWbjGtYui2M+CNoyt5H8XxGdHULO3grw=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-f6265LzKJ2v8eFrX6su7llc+THmKDX950hwsND5LeBE=",
      "url": "_framework/dotnet.5n4csxbdho.js"
    },
    {
      "hash": "sha256-KtVZiBdeDZBHxG5hpWCQdSi/NrghjEF7KY47BO6Yvug=",
      "url": "_framework/dotnet.native.69yz1vsw7q.js"
    },
    {
      "hash": "sha256-dBtXKQNpgCXG8kQPEhEC1RAyJeCxxaHhJvIBliLdu6w=",
      "url": "_framework/dotnet.native.ccp1q1z2zh.wasm"
    },
    {
      "hash": "sha256-CHJJM/ZgtVetJLyVfm7XXfr1VQfR5EEU6T/EgGPi+Fc=",
      "url": "_framework/dotnet.runtime.gqgh3r3nhq.js"
    },
    {
      "hash": "sha256-M6yQszO4MYAipnE/DqxBNtdb6p8mA9T/qJ0ULntfOzc=",
      "url": "_framework/netstandard.nr1tu0e9sr.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-6/cowp0JxXU7i8tMJKQ5H6LY+WVX4C8au46UqaRn6qU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-h+Frw3DrGQV4d9+Vk0DQ7hWgVkoi5ZSLK1scn/n1uIA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-BBwCxlx+/cC76bWkXY1Hn91b+/7EsuZuEzAV87+vBbE=",
      "url": "site.min.css"
    }
  ]
};
