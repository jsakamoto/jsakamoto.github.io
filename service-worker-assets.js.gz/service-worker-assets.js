self.assetsManifest = {
  "version": "5lwrqYwc",
  "assets": [
    {
      "hash": "sha256-IdQk7PSAjWg2nyye6IkiPavaxEFsMHTLdOGbicsmo7I=",
      "url": "BlazorWasmPreRendering.Build.9609fvaqjm.lib.module.js"
    },
    {
      "hash": "sha256-yXN40g8pYp2eufc7T4BysaEKwjlOOE+cOZ+wj/2Kf04=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-x4hAHFuJ3tW/7yWCtqmsEpNxjFRKmBqhgcfFDp/2GMc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-xnGdwzkKBNB9AVBUmJhuorDlgk/UU8fFiuQlJ5jVrNc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.2drl8nn3fe.bundle.scp.css"
    },
    {
      "hash": "sha256-/II9q9tn0OqRhJDmNb4H+Utq3VfUWWYECjtjwhR1Xgo=",
      "url": "_framework/CUIFlavoredPortfolioSite.wx4sxdixpe.wasm"
    },
    {
      "hash": "sha256-Foe9GFjf90oQR41C8LQewt+QjFVVcjPFJ2oaa/5BZm8=",
      "url": "_framework/CommandLineSwitchParser.m4vm0sxx0r.wasm"
    },
    {
      "hash": "sha256-lYKmfxpMUDNiCKVw4h1Jrxm44Nvf0ODiZbOhYtSvbFs=",
      "url": "_framework/Figgle.9n58c2629i.wasm"
    },
    {
      "hash": "sha256-U0pF8PfRUh77UlEQzwrI6QRdPs0eoLq3mZFxjo9Mw0s=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xzm1zep8db.wasm"
    },
    {
      "hash": "sha256-fxrMLLZ/gwxbabr3A54hhcirsoN+/G8yFaucvoxJqhk=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nyuvolec53.wasm"
    },
    {
      "hash": "sha256-r2l9NLn1Uu/WW0hbymAXbcjT4C0psQwaPFqxAmdxL5w=",
      "url": "_framework/Microsoft.AspNetCore.Components.dtrazuvrvm.wasm"
    },
    {
      "hash": "sha256-7AON0O0BF+ReQX85GvuXG9LRzeqf1fr9pe62euvnO0c=",
      "url": "_framework/Microsoft.Extensions.Configuration.4a8gqfkd9y.wasm"
    },
    {
      "hash": "sha256-ecKkbVb3Lhkp86/XN/n/3VQ5yPcR/5O0ZcOZv9IYCXc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.p4hztt7d1b.wasm"
    },
    {
      "hash": "sha256-Kkm5yhLHpE3mKuh44I2Uq71Z8qkIs8IRv39xy5XkKZM=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.ee954lo6yv.wasm"
    },
    {
      "hash": "sha256-RNNBNKN4z1gGVzl17/iiC+TBkMdOPuLXMq+mIIsDDps=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.k8hsp9pmvn.wasm"
    },
    {
      "hash": "sha256-m918avm93STypsxQeTizgPFEms9lpF7FbYTLwUeYBJ4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.97a3k2bxjv.wasm"
    },
    {
      "hash": "sha256-j6E9SjkxqkH3zlmHTUL/FMwpeB8exrUKKmP5LSGQaOE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.xsuqkn3vjc.wasm"
    },
    {
      "hash": "sha256-7VkZi+zUmN+PIaU6mfpdG8roHT1w43L/4DCDkmEkTwg=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.3cidgatzd9.wasm"
    },
    {
      "hash": "sha256-mGoTbWiv99FJoeOKGurDmGoopfy52pklSKJIvrC6CnI=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.c7pw3k7gpl.wasm"
    },
    {
      "hash": "sha256-V6naAUM8v18XnXNqgObSTSTM6WznHbemhjnMlVhfpGM=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.bfjwrpc7xz.wasm"
    },
    {
      "hash": "sha256-CFNl+Or7Drmcsm+f1SANEqdQ6qTJXaAPhcNnUUV8HCE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8sst2155dq.wasm"
    },
    {
      "hash": "sha256-wtBr9zcRWDX8E2+R3JuzP8S8CN+UCXHy43Er87wYMmI=",
      "url": "_framework/Microsoft.Extensions.Logging.mq49rlk448.wasm"
    },
    {
      "hash": "sha256-JUbl2n50J3UrLpwkA4BzRAv8mwnRCjzMowTZYQM7sWo=",
      "url": "_framework/Microsoft.Extensions.Options.5cr7kf590p.wasm"
    },
    {
      "hash": "sha256-nmRcXHCY9K3aG4gUlhCA+J4ozK0m1Qex+a/XVnqJkeE=",
      "url": "_framework/Microsoft.Extensions.Primitives.y4vnq94dbe.wasm"
    },
    {
      "hash": "sha256-J12xQgmtWHPa58h5FrF/SHRXyb21e9S57typRJhsf34=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.d71n9hnpwh.wasm"
    },
    {
      "hash": "sha256-G6Wyr3grtUmKZqJs6bVwNvtuZ7LCeQiOyZVxn4SPuIM=",
      "url": "_framework/Microsoft.JSInterop.tmf743ii6b.wasm"
    },
    {
      "hash": "sha256-d408xnraJS9PXn6myST+l6E6McGSQqvdvlyGSqD/xO8=",
      "url": "_framework/System.Collections.78x1b5lj10.wasm"
    },
    {
      "hash": "sha256-kzAdQrjeuJPSfztwYX9pJnjMjFDhilWDysB4ADdzIUE=",
      "url": "_framework/System.Collections.Concurrent.9x8pitj3aj.wasm"
    },
    {
      "hash": "sha256-HbWRUbzafzbYeXhHxjkTB+vCyuU1mNDpqBopQBdWCME=",
      "url": "_framework/System.Collections.Immutable.vdfgd3k5dh.wasm"
    },
    {
      "hash": "sha256-mTYtnc7uNpYP+dPlaQVKmW6XpSGOJwH4VH3Pub8QiAw=",
      "url": "_framework/System.ComponentModel.df7872r4vc.wasm"
    },
    {
      "hash": "sha256-ySQ4r2gbSdaVgy0bj9SpuEK7Z7tKAoz7XS6nJ0kuizU=",
      "url": "_framework/System.Console.v64srnmvqf.wasm"
    },
    {
      "hash": "sha256-qOFwSxc9E8Jxy1eT5zF8iBQvvkgSy92Iz+b+CxldEY0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0u74hg373z.wasm"
    },
    {
      "hash": "sha256-3AIKMLOgYocj0knLqhwrGjlEdFUQlXEM8o/7yH55z+A=",
      "url": "_framework/System.IO.Compression.w7cgx8w2xv.wasm"
    },
    {
      "hash": "sha256-J/1aPN+FxxTbtAxMIN3gJeVId686kFSMZKU1Z/KTL1M=",
      "url": "_framework/System.IO.Pipelines.poe6z4m2xv.wasm"
    },
    {
      "hash": "sha256-iBF/dzkwpR+vNo+T4zVZaFH2FBeSQ8dW/wlyyvP7qdo=",
      "url": "_framework/System.Linq.wu6vyy1yqv.wasm"
    },
    {
      "hash": "sha256-3MVdg8iWwL7nbkhUonIy1oxnFmEdAYsib4fj+o9339k=",
      "url": "_framework/System.Memory.kwh2bux1ga.wasm"
    },
    {
      "hash": "sha256-x1jlRAexRmIsSkkHfHq3IL38RoY6JtM95KucveclKvc=",
      "url": "_framework/System.Net.Http.b39bi5tgy0.wasm"
    },
    {
      "hash": "sha256-4I+5cWRCFBN3LmPPPpC1oICUDLajtHMdVT93qkDQnGA=",
      "url": "_framework/System.Net.Primitives.8y188jia7e.wasm"
    },
    {
      "hash": "sha256-Q1pcaJA5ELkbLHWHIte62Ew/6RrWWmMf2o75onTKlYE=",
      "url": "_framework/System.Private.CoreLib.zw654hcepu.wasm"
    },
    {
      "hash": "sha256-szh2+sdjVv2BERlxP5wq4rsWnGVwVAcP5EyM6eVame0=",
      "url": "_framework/System.Private.Uri.9hibhtd2pk.wasm"
    },
    {
      "hash": "sha256-IAJJthEXWZvoSIDm7oGWNHwiA/abb4JP7hnLvq7OTrc=",
      "url": "_framework/System.Reflection.0wu2pfak1o.wasm"
    },
    {
      "hash": "sha256-8cP9aAjNtRDBGdTMYB2lvKBGVUjSYX8qrqnOujMUG4c=",
      "url": "_framework/System.Reflection.Extensions.rtaxb7q6t7.wasm"
    },
    {
      "hash": "sha256-lWkrM94+gTM3zW5dojLhsmMEYjVYMzxRpbGJaBvvCxI=",
      "url": "_framework/System.Runtime.9z69qh6loi.wasm"
    },
    {
      "hash": "sha256-rHH+JsFuLO6OKkmvXHR716jwPg3RKD1gjWJ5TSWHOu8=",
      "url": "_framework/System.Runtime.Extensions.w9jbgys78d.wasm"
    },
    {
      "hash": "sha256-IVUnwr/CaCiOShBdhUOpRfTE/MIsiM80P3zS0owKSTI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.bphppbohl0.wasm"
    },
    {
      "hash": "sha256-u79XAKNFTfGXuY5O8uyA42e83xMi6WDXC3+iIYiYx5c=",
      "url": "_framework/System.Security.Cryptography.5oy7977kf7.wasm"
    },
    {
      "hash": "sha256-iFU/UWpx1wxmiiCtcDYP1kPaJdGWYnUfRdebDRet7qI=",
      "url": "_framework/System.Text.Encodings.Web.49cad3q54u.wasm"
    },
    {
      "hash": "sha256-WsrF0SAGQfgWXCVA0I/4WRLwcUzDLPsLBy8kxCJcK0k=",
      "url": "_framework/System.Text.Json.61fhovn4ta.wasm"
    },
    {
      "hash": "sha256-r0fprNuGa+P8hBZ+69hrYrWdigRlf6qWmmjE/YQ5+u0=",
      "url": "_framework/System.Text.RegularExpressions.dtnfuh9xsf.wasm"
    },
    {
      "hash": "sha256-+r/t9gCMj7yiDSffiH4wmq+ZTEhTQ7+lb/tFrT9y85M=",
      "url": "_framework/System.Threading.mop80z6tcd.wasm"
    },
    {
      "hash": "sha256-a0HrSmY7BOMv31wjSVfWReWEEmdIxjFUAmXsmMXRMgQ=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.zmzs621edh.wasm"
    },
    {
      "hash": "sha256-rSnX8E60A28YMjTWZYoEAErKvFfCbsD+lTiLXciPzw8=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.lid1nuwyba.wasm"
    },
    {
      "hash": "sha256-6nSEs5V2VGYQ6LKQGrykvTsoNMqcKHx7uGOUalHERdU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.2ye5ebkuc0.wasm"
    },
    {
      "hash": "sha256-Qyrzd9+dq6ipeaD9gOv0kN4ygl7JuoAzNBWYLzT+dLs=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dswvi7pnin.wasm"
    },
    {
      "hash": "sha256-KqdT4BJgh8et0cNn9eYY7MXq5jyWbJctcqjCBuwCQ1U=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.afnpi90o3x.wasm"
    },
    {
      "hash": "sha256-h5BykV52WXDQQYSSeQYmnw2hLafu9fcAvqRQUCbYr2Q=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wK4d75N7t8qDNB2PXHAvew2pZnWUklx2XJPmmlACEsE=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-rq+nyR2ao6xXp2116dvWP+M38U1ebKzUj60aie1tOmg=",
      "url": "_framework/dotnet.native.2ft3493y9d.wasm"
    },
    {
      "hash": "sha256-IgZUZn0eRpiQ1jU6cW/OLGmQdx5fJRaW8RiB7FWUrpQ=",
      "url": "_framework/dotnet.native.yv6o1w2unj.js"
    },
    {
      "hash": "sha256-+av9N6B3E0Us0zxxiBjfoekhKbRdhgvDrRIuA4xuBvI=",
      "url": "_framework/dotnet.runtime.tzjft7ib9j.js"
    },
    {
      "hash": "sha256-DU6sVPBXKheqR4OU8Wd0cvDAkjgaVpogD/fXLkBb5zQ=",
      "url": "_framework/dotnet.vhv6d806fy.js"
    },
    {
      "hash": "sha256-7B5CkJ2M/ilLTQ7yHYgZJf5vxEC6EbmJaja4r3jlRFg=",
      "url": "_framework/netstandard.c4pfi41ggv.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-bPZI+vLdw3UaXotHN0qQYCR2Hd8BFXgKtnBomlGa6pc=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-h+Frw3DrGQV4d9+Vk0DQ7hWgVkoi5ZSLK1scn/n1uIA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-BBwCxlx+/cC76bWkXY1Hn91b+/7EsuZuEzAV87+vBbE=",
      "url": "site.min.css"
    }
  ]
};
