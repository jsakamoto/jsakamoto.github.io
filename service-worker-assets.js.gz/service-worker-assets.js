self.assetsManifest = {
  "version": "jnGM5+qk",
  "assets": [
    {
      "hash": "sha256-UwezpSZ5U6y5SoCmStNG9ekksy9a7X3WUO1Q0dwmEZ8=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-Z094C6tvTOKvix221ZuSPsaaNvGOp0XKqThmB4vfuOA=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lib.module.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-FusWOhPOKkLq10+x/UFtqpm/7B66OiSZdnFf1FsNKa8=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bundle.scp.css"
    },
    {
      "hash": "sha256-SgDfk9RyL7jvEK1salCLcmm5zGV0S/qwmv2e/9xW6TQ=",
      "url": "_framework/CUIFlavoredPortfolioSite.uuafzmouil.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.sr4z4qwcg5.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.s8k3msdvya.wasm"
    },
    {
      "hash": "sha256-xMaWzn7ggQH4aB3DHT7s22/SNgseN4g3SvJkrcHTI4U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.8lglmfcjre.wasm"
    },
    {
      "hash": "sha256-EZKN4v0bsx4yrL58Lmmn1lWa1KQNWaHsIl0WEVRVUNA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.1o7pbd2l2j.wasm"
    },
    {
      "hash": "sha256-k6WYwl3npXA87rW6ckL51X/m1JOZhbCLLJDnZqWLeGY=",
      "url": "_framework/Microsoft.AspNetCore.Components.b20to6xoei.wasm"
    },
    {
      "hash": "sha256-QHOGfLmuGdFztkOfOwQ1oMcFwLrwa8d+4sWJJIGwV6k=",
      "url": "_framework/Microsoft.Extensions.Configuration.8uk3noxgmv.wasm"
    },
    {
      "hash": "sha256-GHD3PoxF3n+Cmylqax0M1LwXK1HAWlJhMom7gTRF0cg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.wq6jn0bf20.wasm"
    },
    {
      "hash": "sha256-5f/kRCFVRpFyWz4ZM53EWNQiMJvCGloKw/OIk5qah0o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.l4cyqta4uk.wasm"
    },
    {
      "hash": "sha256-5woqEAC93MlLVfoxdvJjYTVzpmCc/bi6gF8wzsjAiBg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.f2djyo0m0n.wasm"
    },
    {
      "hash": "sha256-HUVppHa4oLmbWsH+gCdOLhiDRJBDrQIH5HMNYZzl5ro=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b2xekeldhw.wasm"
    },
    {
      "hash": "sha256-lsL3kfLH4UB3mJ5UIUnpTPmI7QkolXxFivATumbgMv0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.moqa9dqyn3.wasm"
    },
    {
      "hash": "sha256-tr+EhgDuiQZYi+a9YAUpaaPf4jwAcqPul/opRE8eZd0=",
      "url": "_framework/Microsoft.Extensions.Logging.a38f1ed6u5.wasm"
    },
    {
      "hash": "sha256-BIyB5S9IXQ46HOy97CWVBbPpoL/zrM67w0Ck0R6WK9g=",
      "url": "_framework/Microsoft.Extensions.Options.0l1wscbvap.wasm"
    },
    {
      "hash": "sha256-E87hZGhaK5YP56Lo3f80aITj+8StUfs/6TNkmz1b3qQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.jo6l1avrrg.wasm"
    },
    {
      "hash": "sha256-Sf3QTJxcAA7QrjQ6wlTsh6j0qw1vUl9mPVhO1Dvv7es=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.vi5zotpb9r.wasm"
    },
    {
      "hash": "sha256-EZfs/Q5VYRcuMUj1cl1Cw1BEBHvtRKvrsa7bcHZ2Agg=",
      "url": "_framework/Microsoft.JSInterop.pyj8ch57rp.wasm"
    },
    {
      "hash": "sha256-+JjYvxTIrAyQBVIM5aThbRsmRF4GSe76GqmCuKTrl4Q=",
      "url": "_framework/System.Collections.8wwuty6o8u.wasm"
    },
    {
      "hash": "sha256-3yMJDbTpbMAZKLdL4ndARVhx3A7vb0S6LJtqS5pZiNk=",
      "url": "_framework/System.Collections.Concurrent.7ms4mxs836.wasm"
    },
    {
      "hash": "sha256-SKSwLVAFm8rOKQ3yWUDgxYVkxMGHITJSdycte6k/ppo=",
      "url": "_framework/System.Collections.Immutable.o4dx32zp6f.wasm"
    },
    {
      "hash": "sha256-M+OiIE+Oyx/oKWxWqI26UnvKE3VJ2nAKycb2WJAt3wY=",
      "url": "_framework/System.ComponentModel.x3o7f6y5sp.wasm"
    },
    {
      "hash": "sha256-TVAoGJltVYQQxiCDHE6iNstE9qFIkSaIBeRBgCUSKrM=",
      "url": "_framework/System.Console.tc4187go9c.wasm"
    },
    {
      "hash": "sha256-TV+aUyq45gQLL8YcdqhGiQ/rPGOGWS6Z5xhRsA1pWek=",
      "url": "_framework/System.IO.Compression.dwgz3n0esv.wasm"
    },
    {
      "hash": "sha256-uF8ZFtMT3UcQ+rksd+djr/mp2VMOw/EUpnBxgOW0QlQ=",
      "url": "_framework/System.IO.Pipelines.o49ueulm8k.wasm"
    },
    {
      "hash": "sha256-fHpBjsr3SMV5SGcRa36bdr1WTfbDGoaVOPjbKbAhThM=",
      "url": "_framework/System.Linq.8p374as3rc.wasm"
    },
    {
      "hash": "sha256-bpUCWxaqfzjd6hiVCO/fthtvgtAmmyYA6oe6satWKe0=",
      "url": "_framework/System.Memory.a2ghrhaeq4.wasm"
    },
    {
      "hash": "sha256-jEFAbL0lgM0awxjQYo17lcuqJwQskgTdY/9g/3ZeiGk=",
      "url": "_framework/System.Net.Http.wvdtixi319.wasm"
    },
    {
      "hash": "sha256-21cWyy6ao2n+qAbS+vB+89T7itFgP78Prg5NbWZsd38=",
      "url": "_framework/System.Net.Primitives.hphy61fras.wasm"
    },
    {
      "hash": "sha256-WTodYYVCbFKZggPCQ5sCN4/m+L99eiIK7VdVjTLtDD4=",
      "url": "_framework/System.Private.CoreLib.bni1tda29p.wasm"
    },
    {
      "hash": "sha256-xnB8ZOddx8DurjeL1FPzMiyTVoQW9ySZRjgbb7zoer8=",
      "url": "_framework/System.Private.Uri.2muxaru0gm.wasm"
    },
    {
      "hash": "sha256-sKIZULP9et9y3Z5Mn4ixfSiE8OfYH0aOxhzR0eC54HI=",
      "url": "_framework/System.Reflection.Extensions.w8bnachcew.wasm"
    },
    {
      "hash": "sha256-mCdnt7h/gghKCYZ+8cuFVoIbvAIJKXOz8heGwI4BIAc=",
      "url": "_framework/System.Reflection.g2ojz1kxuj.wasm"
    },
    {
      "hash": "sha256-x/+rK9YLNQgyQcikntoTpGrrXY9vvaPAfyT6dxEKvIs=",
      "url": "_framework/System.Runtime.Extensions.bnw6de3fi8.wasm"
    },
    {
      "hash": "sha256-iyHAcUW3MeBhiBJYRDE3uHM1+K3ghZ+2EQK73u2xaM4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.vbi7xy05cc.wasm"
    },
    {
      "hash": "sha256-WTQwPwEN3rWWK9hPqOQS9B/pSYpUea+zecJWXFMRjL4=",
      "url": "_framework/System.Runtime.vaq2yivgoy.wasm"
    },
    {
      "hash": "sha256-8NwU9VF4mPgJXLc643br1Ipk+O7DZ8YvCEadRXxnfeE=",
      "url": "_framework/System.Text.Encodings.Web.ouyex9zmsy.wasm"
    },
    {
      "hash": "sha256-3MbDjctXfM0qvJvba0BB+pimvRTOJryoHOX4eV9gaLo=",
      "url": "_framework/System.Text.Json.k6jv0p9zx6.wasm"
    },
    {
      "hash": "sha256-FE4acjT7E5cNgvaBuvy/sOsacreezkV+vbcaDU6oMZI=",
      "url": "_framework/System.Text.RegularExpressions.4ozuizw2gl.wasm"
    },
    {
      "hash": "sha256-nvJ3jBZyFxQ0Ah384UEBcclL0FkV5CRGAwbUlnWAR74=",
      "url": "_framework/System.Threading.e40w6tlim8.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.rzopx1zxmr.wasm"
    },
    {
      "hash": "sha256-NYA/dRWBU0sE9br6E2oXiQ5WHD3AAwXZvE+6h5pefDY=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.19vcfez3n4.wasm"
    },
    {
      "hash": "sha256-weCJXWDU5zdPFFtz1l8hFf5cGyJf7Njav44MN3D8lqg=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.9a5840lppl.wasm"
    },
    {
      "hash": "sha256-rLxY8GcXMc+DtDtierw+tYTWjmMqRtyqbLVk7ApPs8A=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.c6rjv9zjd9.wasm"
    },
    {
      "hash": "sha256-DfVvM/mfswFj4vsQDSsiVHFtPpHGPp+GMGzzCpy5wxE=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.9tj3m60764.wasm"
    },
    {
      "hash": "sha256-l0h6FoD7QguUr6krmUr/moVMBhufefh6aLEMV4alkm8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-C6VEWJvr8/4p8V9CoiDu1P5WjlEOa5J8TwcJ/G/8V14=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3+oINbl9anIpOQa27gJF6ci1He9ldU/ZrulG/oAmZBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-0wUrNLYOqq31hhlhHQVF+mYc2rcQQFq0Q2uVsfhRVpU=",
      "url": "_framework/dotnet.native.1biabhbk4m.wasm"
    },
    {
      "hash": "sha256-X5aCg+/CbbhwSgCYaoS2V2CKkXQnF9ePLRea0nwNSTk=",
      "url": "_framework/dotnet.native.rp07vyt6vg.js"
    },
    {
      "hash": "sha256-e/Ee0XzTQHVzg6pZms6FR5P6yEpTgaACDSAZCGD1PUo=",
      "url": "_framework/dotnet.runtime.ju77aherdp.js"
    },
    {
      "hash": "sha256-6aPAZCS1dMsSQWLY2zShnlzPy4mMlApRxTypKm6KDoY=",
      "url": "_framework/netstandard.xq63v0yv2u.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-tRR7v6ZqfNVt4+aFOcEJrxXgZY/QUg9lcVUseqpn0Ag=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-XstODeHpSfApNv74N2EjSbPos8GR38PcxhBEt9rigMA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-RBUikAEI4NQnEO55CIYdZvR1FONxzbgclc9+WG6Pj2M=",
      "url": "site.min.css"
    }
  ]
};
