self.assetsManifest = {
  "version": "KNU7KH2Q",
  "assets": [
    {
      "hash": "sha256-UwezpSZ5U6y5SoCmStNG9ekksy9a7X3WUO1Q0dwmEZ8=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-Z094C6tvTOKvix221ZuSPsaaNvGOp0XKqThmB4vfuOA=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lib.module.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-FusWOhPOKkLq10+x/UFtqpm/7B66OiSZdnFf1FsNKa8=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bundle.scp.css"
    },
    {
      "hash": "sha256-eG4K87+WiikBC2WZ/e2H6ne32hXpsKHqtvHkS/1JZO4=",
      "url": "_framework/CUIFlavoredPortfolioSite.wasm"
    },
    {
      "hash": "sha256-6C4lpQHhVm9zj9eSWImlbOfLMjZc4Kf2OUiJSjTpLkA=",
      "url": "_framework/CommandLineSwitchParser.wasm"
    },
    {
      "hash": "sha256-xCBIOWi/r/unhhhVJmmGeviYucogDlU74/E1Sdddgg8=",
      "url": "_framework/Figgle.wasm"
    },
    {
      "hash": "sha256-KS+AnR1fsoUIf8UDze4+/PwwwmmCakd9iwRJUSj7zKU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.wasm"
    },
    {
      "hash": "sha256-VZr84E6nIya/7t8kbS/GbqTZcr49OX8CaPaihInVRXU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.wasm"
    },
    {
      "hash": "sha256-JynkopPKUaAaJwVaGeaYI1o8fkr7k2TYpwh7rz4TCY8=",
      "url": "_framework/Microsoft.AspNetCore.Components.wasm"
    },
    {
      "hash": "sha256-tJ9m6wbTyRxu2bacmqf8cOEsJ8swvCvp6B3EGsKjbYA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.wasm"
    },
    {
      "hash": "sha256-72R5Luv1GgYMi8PIVbafuKcYMDvEVagwA23N3wf+mYg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.wasm"
    },
    {
      "hash": "sha256-+IBel12+dKYXqle+KNfv0n2xjjgBFxhyv47MH/GAg8A=",
      "url": "_framework/Microsoft.Extensions.Configuration.wasm"
    },
    {
      "hash": "sha256-WQv2K7sdzSK5JLedDRW2Puhd6bpSTnO8O/TgeR6OBko=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.wasm"
    },
    {
      "hash": "sha256-JnAeG69TMYFl3P+1KVohOB15Wcx4i/l1rVTEUAbGQds=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.wasm"
    },
    {
      "hash": "sha256-SeZpBps1Y04W+kEmAt3ZJDn1Q8PUKoue1pOsjgtGng8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.wasm"
    },
    {
      "hash": "sha256-EmwCpAf/JiK6VahWBNoqkxDngTuEBNNJXwlPE40L/5g=",
      "url": "_framework/Microsoft.Extensions.Logging.wasm"
    },
    {
      "hash": "sha256-/yb83iX9DQWSoMA1yFgpCwpT8B0i59Eu1LXo7M+RSJc=",
      "url": "_framework/Microsoft.Extensions.Options.wasm"
    },
    {
      "hash": "sha256-LfNT2xeGekjR1YV9ujruP5ehzWxhgfycqMc4xmqMy98=",
      "url": "_framework/Microsoft.Extensions.Primitives.wasm"
    },
    {
      "hash": "sha256-FUI9rc4hBXDuUOwHTka1P2I8X0WWayZZt/P7l2zhLds=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.wasm"
    },
    {
      "hash": "sha256-FFP76GNDPkU1DHiwuuCL6rYcv9QqsqGv8h9m7N5arRs=",
      "url": "_framework/Microsoft.JSInterop.wasm"
    },
    {
      "hash": "sha256-7knc8Uk6z4Fp2EXhOIz+p/COxn9qGuapE+3t32p8INc=",
      "url": "_framework/System.Collections.Concurrent.wasm"
    },
    {
      "hash": "sha256-u0GLzRBP/ucGIXSQagwJHIvh9l1A/Bi38z2RqIXX1Jo=",
      "url": "_framework/System.Collections.wasm"
    },
    {
      "hash": "sha256-f5e8LaaxPtLHMUhHiWaiaLeuQNmIMKvJYv63f4twbDs=",
      "url": "_framework/System.ComponentModel.wasm"
    },
    {
      "hash": "sha256-Q8xC3TBzRDCKu3U/d2SBUmMNs+7ZdfXfICfWNSFWRQE=",
      "url": "_framework/System.Console.wasm"
    },
    {
      "hash": "sha256-OOjllUY1glqCA/wD/rNrNtc/ERhumEOZoCx4if8I0WA=",
      "url": "_framework/System.IO.Compression.wasm"
    },
    {
      "hash": "sha256-8KlzqukhOnZ89sd7rUd9+T7cwjkGfXddUWDrB4CWAuI=",
      "url": "_framework/System.Linq.wasm"
    },
    {
      "hash": "sha256-zMvhUGj5cXFmO/ynfEYNI9eJJY2NxTMnL53qvt6G4wU=",
      "url": "_framework/System.Memory.wasm"
    },
    {
      "hash": "sha256-maLG0WWtuHLeRy0eWzxH+dmDB2tuYuWXNrXBVI6y2cU=",
      "url": "_framework/System.Net.Http.wasm"
    },
    {
      "hash": "sha256-k1OtKaMt2UdQ/q9/bmtEaNGU8MHhEy5+0Il85h4QnRY=",
      "url": "_framework/System.Net.Primitives.wasm"
    },
    {
      "hash": "sha256-qvqZX1nRN/iO3KE/AKcl2cLNXhGUFiJmUICXj7YSlRQ=",
      "url": "_framework/System.Private.CoreLib.wasm"
    },
    {
      "hash": "sha256-tYKJS1UiM20+RIRSNCCfVKfPahgWhXJbp0/AyvvBIXM=",
      "url": "_framework/System.Private.Uri.wasm"
    },
    {
      "hash": "sha256-NAgMLK6VXFw0VRGQ1kp7KKS0HXYCoFi7ohyc3R6JEvw=",
      "url": "_framework/System.Reflection.Extensions.wasm"
    },
    {
      "hash": "sha256-7EMHT8xgcoPXRa1Xg1uhgovb+HPnkYYFGK9eRyPbrhs=",
      "url": "_framework/System.Reflection.wasm"
    },
    {
      "hash": "sha256-VUAGEh8P1HAcWBEiP3aNIxVGNqCSr5xmW7mo08C2gnI=",
      "url": "_framework/System.Runtime.Extensions.wasm"
    },
    {
      "hash": "sha256-0UCGoAJI0lPlN4zUnED0Q3zZyGRDmXO6Gny6Au+gr8o=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.wasm"
    },
    {
      "hash": "sha256-hJPKe8Tg6lucut4X1vWHdyMLE5WvqmdvZP/nJ2JTHBQ=",
      "url": "_framework/System.Runtime.wasm"
    },
    {
      "hash": "sha256-9HjoXJdGE6TOBg4zYa6W1GuxhUXvRTuA38QVh1hVmAc=",
      "url": "_framework/System.Text.Encodings.Web.wasm"
    },
    {
      "hash": "sha256-Zk2aih6bNVVo2h5Z2NnSbujhD/dAcm8B60PWjZOPRvg=",
      "url": "_framework/System.Text.Json.wasm"
    },
    {
      "hash": "sha256-7xH9A5sHCbXjxYmsaG3W7uxvMOLQ/5GLQZ3X9ZHElks=",
      "url": "_framework/System.Text.RegularExpressions.wasm"
    },
    {
      "hash": "sha256-nBmObtov1kgXQXOiF8qvq1v2BVS+hIGBg037VfHbMvM=",
      "url": "_framework/System.Threading.wasm"
    },
    {
      "hash": "sha256-OeDtBknZYfLD+LbXrcmdd3WZFATGFGiv7pZ2hARtxTs=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.wasm"
    },
    {
      "hash": "sha256-DZ3NTz/YomtAXPbR8Bb0ppPd9FGk1EVWeG9UCIWpZCo=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.wasm"
    },
    {
      "hash": "sha256-weCJXWDU5zdPFFtz1l8hFf5cGyJf7Njav44MN3D8lqg=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.wasm"
    },
    {
      "hash": "sha256-rLxY8GcXMc+DtDtierw+tYTWjmMqRtyqbLVk7ApPs8A=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.wasm"
    },
    {
      "hash": "sha256-DfVvM/mfswFj4vsQDSsiVHFtPpHGPp+GMGzzCpy5wxE=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.wasm"
    },
    {
      "hash": "sha256-XeSs640O8iCE/4+RKkdA+V+vyGhbDyp6j1RZWJj8Drc=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-zu8OxxrFk2dWerX87BBnCH4oxVI8UqkS6aIGauq4+Rs=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-cFXhaDG+S35gJ95i+93KWbSlpAs2fEqy8m3nsAE0d1A=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-IhDrBSW9lk/t624v6wJy0ExVkt1cWw62VooAPVejsjU=",
      "url": "_framework/dotnet.native.9.0.0-preview.5.24306.7.eod10yvjm4.js"
    },
    {
      "hash": "sha256-fHY/pg6FbvhBrAqpHWU6PA+1F2mmrM/19QKEHtD4Egc=",
      "url": "_framework/dotnet.native.wasm"
    },
    {
      "hash": "sha256-7tiSBBS0C6jIYHEU4RwIi6DmDWdKHXYfg4fwmw+DF/Q=",
      "url": "_framework/dotnet.runtime.9.0.0-preview.5.24306.7.ehgmojspsi.js"
    },
    {
      "hash": "sha256-ANNoBGdleXwISztpg/XdjddpAheyLLnZwsYfB41cRTQ=",
      "url": "_framework/netstandard.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-tRR7v6ZqfNVt4+aFOcEJrxXgZY/QUg9lcVUseqpn0Ag=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-XstODeHpSfApNv74N2EjSbPos8GR38PcxhBEt9rigMA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-RBUikAEI4NQnEO55CIYdZvR1FONxzbgclc9+WG6Pj2M=",
      "url": "site.min.css"
    }
  ]
};
