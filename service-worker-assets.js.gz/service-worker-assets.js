self.assetsManifest = {
  "version": "c9nJ1TLR",
  "assets": [
    {
      "hash": "sha256-IdQk7PSAjWg2nyye6IkiPavaxEFsMHTLdOGbicsmo7I=",
      "url": "BlazorWasmPreRendering.Build.9609fvaqjm.lib.module.js"
    },
    {
      "hash": "sha256-yXN40g8pYp2eufc7T4BysaEKwjlOOE+cOZ+wj/2Kf04=",
      "url": "CUIFlavoredPortfolioSite.styles.css"
    },
    {
      "hash": "sha256-DkTY8YIgtanD9viMrpdjx6ujFL/B/pO1F3i4w/rcG9A=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-x4hAHFuJ3tW/7yWCtqmsEpNxjFRKmBqhgcfFDp/2GMc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-xnGdwzkKBNB9AVBUmJhuorDlgk/UU8fFiuQlJ5jVrNc=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.2drl8nn3fe.bundle.scp.css"
    },
    {
      "hash": "sha256-kMaX0kpzpmBsaCVpvSnQaEfgPwBJDZ5p6i+giLv1AyU=",
      "url": "_framework/CUIFlavoredPortfolioSite.kjdgqtr26x.wasm"
    },
    {
      "hash": "sha256-Foe9GFjf90oQR41C8LQewt+QjFVVcjPFJ2oaa/5BZm8=",
      "url": "_framework/CommandLineSwitchParser.m4vm0sxx0r.wasm"
    },
    {
      "hash": "sha256-lYKmfxpMUDNiCKVw4h1Jrxm44Nvf0ODiZbOhYtSvbFs=",
      "url": "_framework/Figgle.9n58c2629i.wasm"
    },
    {
      "hash": "sha256-ngEYV8lvY7wGQfxo4+8ocbn7s3e1Ia5OoLoRj5oiuTQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.2vkg481297.wasm"
    },
    {
      "hash": "sha256-jVsJVhjMbO6q5xrmaXUQ1oCkhw0ZNO974d3P4kIF+qI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.jczarmwf1i.wasm"
    },
    {
      "hash": "sha256-biioXd9ftXOusH2XfPZv0mzzGauqH2YiGPMGOaR8Zfc=",
      "url": "_framework/Microsoft.AspNetCore.Components.ehy8jtr19i.wasm"
    },
    {
      "hash": "sha256-gPYEp70ZmrxYlpLQw7hcxdmIbQ6vmluxLP8cfyoVWzo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gol3euaj3d.wasm"
    },
    {
      "hash": "sha256-WWSvU1JDlu+bkUC9QASXcgI6FBxn6nqhoi+goYlADAM=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.vaqacjgd1g.wasm"
    },
    {
      "hash": "sha256-it2ZhBMdA01nWq87yJoqpIh2zzD4VlW5qVKw+RKqPzw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q81lkglnox.wasm"
    },
    {
      "hash": "sha256-qprAZs11QknnNWs31jrjGmWxdUsXL6dZqWOH/WHzx8s=",
      "url": "_framework/Microsoft.Extensions.Configuration.e6rfa9mvfw.wasm"
    },
    {
      "hash": "sha256-yt4iHbWdV25CHtl8SqEfioEBLGKJDt0KvbdkK/7M+bc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.2icma7b6le.wasm"
    },
    {
      "hash": "sha256-jxo+s2tQ1ttnsvHv0GfKvqHrm+o+J/1F+8wsAPpKK20=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.nyfzzvsl5t.wasm"
    },
    {
      "hash": "sha256-2jQ7jiew9q+5Ke8i4fl+RClN1kk9u0ejlFTCHyIWg4Q=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.qz20gv1zfo.wasm"
    },
    {
      "hash": "sha256-jrG0mdpst0h6GpNSYnKL6CGIpoqljOAai75Nx5vueow=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.es1aeztafo.wasm"
    },
    {
      "hash": "sha256-UI/VpVCSQq1k6851I2nIRybFHWT0BJkz8pnAhtB+6fs=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.wgrd77yf8o.wasm"
    },
    {
      "hash": "sha256-r3Iazs3gsHLa31/gxI1sxWuwOURMLvnNpkjTyk7ZTgk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.pal6grsnye.wasm"
    },
    {
      "hash": "sha256-TKvpCqOYjJqprbYn0eluY84Nj1RMWjYf/0zCA25CcB0=",
      "url": "_framework/Microsoft.Extensions.Logging.ksbw1ccply.wasm"
    },
    {
      "hash": "sha256-4cImHzukHX1apUbnTrG1BpIqXHL8zFBQ07ZXq7AveT0=",
      "url": "_framework/Microsoft.Extensions.Options.p2ktgi2s7x.wasm"
    },
    {
      "hash": "sha256-mBMb9fkjI1nSxWYduGCYeHUnpEtHR50keueOklvXrIc=",
      "url": "_framework/Microsoft.Extensions.Primitives.8svecu1up5.wasm"
    },
    {
      "hash": "sha256-HtaclgWQM7Z1s67STExTC2BClIKj8i8Bqqmgj1HxvNE=",
      "url": "_framework/Microsoft.JSInterop.2nqtawyzoi.wasm"
    },
    {
      "hash": "sha256-uHbb5b7vnE0GwS6Qws3ipDRp2E0UWNZ9G2JJrz8Au4U=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.kthmj8ue8z.wasm"
    },
    {
      "hash": "sha256-nsmD1QA/OA3NfNz/idsLWRUvEyLkZ98HuFUPBVH4yDc=",
      "url": "_framework/System.Collections.2ogok23vyb.wasm"
    },
    {
      "hash": "sha256-35MIzRyKif8q8z2g+AjtNRi9fGrYQukWGTeF71EomzQ=",
      "url": "_framework/System.Collections.Concurrent.jr08yn8xwm.wasm"
    },
    {
      "hash": "sha256-GGTSvkYmQnccZQuNXW5l0OA6aR07Pd13zQ/CrM9DOsE=",
      "url": "_framework/System.Collections.Immutable.k5dyd86tkb.wasm"
    },
    {
      "hash": "sha256-9s3Ih1he7fvE86Ah8CLHgkOcDwNjdQ2jMduoQFbCk3M=",
      "url": "_framework/System.ComponentModel.er3kikotc9.wasm"
    },
    {
      "hash": "sha256-LuKF84+In39PSnABPWzeRpeIrYRYJ7G1+kVX1OuY4/M=",
      "url": "_framework/System.Console.qlig0wmxw1.wasm"
    },
    {
      "hash": "sha256-W5l+Vvjv0qfXVyrsRAzj+rPaIuwJ3lAxQim+hls0PnU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.50iql5udqe.wasm"
    },
    {
      "hash": "sha256-wEBoyLIsbdnpcNz2NjI2D/ZqnaXXDrPJeh1AhWZ9JbQ=",
      "url": "_framework/System.IO.Compression.sp6laocxus.wasm"
    },
    {
      "hash": "sha256-hnDOQNTIH/aa1TzCygGWtOIjPNT7her4x77kuTUV3To=",
      "url": "_framework/System.IO.Pipelines.yeihgeljvz.wasm"
    },
    {
      "hash": "sha256-qibtNABmm1s0sGv1RgWqmXzMPhvg591bqxm6RIF9538=",
      "url": "_framework/System.Linq.u7llw2uaep.wasm"
    },
    {
      "hash": "sha256-79sXRg2IgHqYYw38Cwe38l7NBiucIqWcZGgVySaHV20=",
      "url": "_framework/System.Memory.l351s2b3s6.wasm"
    },
    {
      "hash": "sha256-k/yA6yA6+tg0VOYpHAWfTslP/jODImldiB0qdYz0VTM=",
      "url": "_framework/System.Net.Http.nnw19myfpk.wasm"
    },
    {
      "hash": "sha256-Dg8xrOEYgzxAyuNJ841CCexFdw3Dk57GMor5mKbykhU=",
      "url": "_framework/System.Net.Primitives.ahebhsx5nj.wasm"
    },
    {
      "hash": "sha256-2tfgs/tVqjX6ksjGFGgYhN45k1uplhgGYhzpGbGt6Sg=",
      "url": "_framework/System.Private.CoreLib.6c35g6ev5o.wasm"
    },
    {
      "hash": "sha256-jG2vbI/tXXW+7qRCo1qvG1mf+Ez+/p9eAUiPURunntQ=",
      "url": "_framework/System.Private.Uri.0dq0522y4l.wasm"
    },
    {
      "hash": "sha256-wRPIPdk2hWHdt9sn1/53oYbepsnMoEnoGF3lR4VQRiE=",
      "url": "_framework/System.Reflection.Extensions.fgfkdhtyin.wasm"
    },
    {
      "hash": "sha256-0+mG9qqEBJ1uQRk+RnrK23n+qsIt3zJi6ojUph2i2ng=",
      "url": "_framework/System.Reflection.nbbqmeyteg.wasm"
    },
    {
      "hash": "sha256-IP0LFp2jodW7nKzuDFx+zNB+kYXG9lFSX8nfXwfUPOk=",
      "url": "_framework/System.Runtime.Extensions.wgwyymrssi.wasm"
    },
    {
      "hash": "sha256-KCr6EFEHkNObycfsKVPt4enUoGUREo0CYSKIn8SX3mk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.0mcgud8ejr.wasm"
    },
    {
      "hash": "sha256-yt+1wfWH1dvVlBMBs9K+sunENbQxCtyUx4JDwUiWY0A=",
      "url": "_framework/System.Runtime.ydw5hfmt65.wasm"
    },
    {
      "hash": "sha256-ixQ7Y96EUtew/0CMYcfe3JMJxDMSCW1WtCS9EkFPT6Q=",
      "url": "_framework/System.Security.Cryptography.9v5btb3qdh.wasm"
    },
    {
      "hash": "sha256-8nBI1ddNriNZSPhgx8eNp32XYzNdwLt2lJr+pvvIL/8=",
      "url": "_framework/System.Text.Encodings.Web.qavawtspew.wasm"
    },
    {
      "hash": "sha256-S/8CXfusKDVoNXBdfSEmsbyon3JXvJEFd2yGIKRl70M=",
      "url": "_framework/System.Text.Json.7xebnuzkm7.wasm"
    },
    {
      "hash": "sha256-xwUhmWGuanXVJXlNZJMOj40cSTsxDmeeqsa2iUDbrB0=",
      "url": "_framework/System.Text.RegularExpressions.tzj09rmt4n.wasm"
    },
    {
      "hash": "sha256-2o/rh+xw52AsQ4SmeWbwJwvow7M9SGKmxKbvJ9PYFUc=",
      "url": "_framework/System.Threading.awhxnw4mgz.wasm"
    },
    {
      "hash": "sha256-a0HrSmY7BOMv31wjSVfWReWEEmdIxjFUAmXsmMXRMgQ=",
      "url": "_framework/Toolbelt.AnsiEscCode.Colorize.zmzs621edh.wasm"
    },
    {
      "hash": "sha256-rSnX8E60A28YMjTWZYoEAErKvFfCbsD+lTiLXciPzw8=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.lid1nuwyba.wasm"
    },
    {
      "hash": "sha256-6nSEs5V2VGYQ6LKQGrykvTsoNMqcKHx7uGOUalHERdU=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.2ye5ebkuc0.wasm"
    },
    {
      "hash": "sha256-Qyrzd9+dq6ipeaD9gOv0kN4ygl7JuoAzNBWYLzT+dLs=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dswvi7pnin.wasm"
    },
    {
      "hash": "sha256-KqdT4BJgh8et0cNn9eYY7MXq5jyWbJctcqjCBuwCQ1U=",
      "url": "_framework/Toolbelt.Web.CssClassInlineBuilder.afnpi90o3x.wasm"
    },
    {
      "hash": "sha256-h5BykV52WXDQQYSSeQYmnw2hLafu9fcAvqRQUCbYr2Q=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wK4d75N7t8qDNB2PXHAvew2pZnWUklx2XJPmmlACEsE=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-QWJr3VRDxjAoaJ3dE1+A3E6DD6wpWlrKcstqPBEcZeI=",
      "url": "_framework/dotnet.dpvr9w2h0v.js"
    },
    {
      "hash": "sha256-69CNxO0ySl2YPamqhVzN8cX7WdgIRj50YQLTY48jCS0=",
      "url": "_framework/dotnet.native.1hz6mc7d3x.js"
    },
    {
      "hash": "sha256-X2cz1zroC8VuI3pAn1s8xq5Q0i7v9VpRiOlFszyAI7Q=",
      "url": "_framework/dotnet.native.v4ntt8vg7d.wasm"
    },
    {
      "hash": "sha256-FsddKLA9kAdfVKI0lZFago0rrc/gNe0yrVtP7+D/qN0=",
      "url": "_framework/dotnet.runtime.uyfhwbfd13.js"
    },
    {
      "hash": "sha256-b8ANKqDEU951qG9h7vZ1Blz/IMKXIudDyhb10diw9/Q=",
      "url": "_framework/netstandard.zvj3t74p9c.wasm"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-cnx8Yix+1jETMB/RstaGVEOO6XUE8SR7Qn823BOLFWU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-jgigJbO/RQghgrjKicODq9/EV3KLRTTI5VMkadLkDyA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9ypkDLoAy6RmO7iZHmZc3dXAZaItavrLA3c35f4puyU=",
      "url": "images/social-preview.png"
    },
    {
      "hash": "sha256-ziloDpmTcsTkmWs6geoS8kMfA0fBej+tQ5v4OPVaD10=",
      "url": "index.html"
    },
    {
      "hash": "sha256-utKu+mA6pLc4I7GjqtfIqL/YJJc3gBYH6SndGKNPSAM=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-RPNQWgTNxb55yhwY4VKLSJMJRhP/TDIY2VUWYQUaJlk=",
      "url": "scripts/helper.js"
    },
    {
      "hash": "sha256-h+Frw3DrGQV4d9+Vk0DQ7hWgVkoi5ZSLK1scn/n1uIA=",
      "url": "site.css"
    },
    {
      "hash": "sha256-BBwCxlx+/cC76bWkXY1Hn91b+/7EsuZuEzAV87+vBbE=",
      "url": "site.min.css"
    }
  ]
};
